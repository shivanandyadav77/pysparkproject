__author__ = "vermanx"
# Filename: ind_relationship_main.py
# Mapping: m_CDB_LS_Party_Relationship
# TRN_NME: LS_CDB_IND_RELATIONSHIP
#
# Source/Target details:
# Input : STREAMING.CDB.CUST-CUST-REL.STD, STREAMING.CDB.TCWPEX1-PCUS-EXT1.STD
# Output: Mongo Collection- LS_CDB_IND_RELATIONSHIP; Kafka Topic- STREAMING.CDB.IND-RELATIONSHIP.LDM
# IND_RELATIONSHIP
#######################################################################################################################
from pyspark.sql.functions import to_json, struct, concat, lit
from py4j.protocol import Py4JJavaError
from pyspark.sql.types import *
from pyspark.sql import SparkSession
import sys
import os
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser


from datetime import datetime
from pyspark.sql.utils import QueryExecutionException
from pyspark.sql.utils import AnalysisException
from pyspark.sql.utils import ParseException

class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message


class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

# Variables populated at runtime
path_kafka_hdfs = sys.argv[1]
mongo_write_collection = sys.argv[2]
kafka_topic = sys.argv[3]
kafka_bootstrap_server = sys.argv[4]
kafka_source_topic_cust_cust_rel = sys.argv[5]
kafka_source_topic_tcwcrx1_crel_ext1 = sys.argv[6]
mongo_driver_cust_rel_collection = sys.argv[7]

#######################################################################################################################

def main():
    try:
        global debug, db_url, db_database
        debug=1

        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        # spark = SparkSession.builder.config("spark.sql.warehouse.dir", u'hdfs:///user/spark/warehouse').getOrCreate()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: SPARK SESSION INITIALIZED. STARTING '
                                                                  'LS_CDB_PARTY_RELATIONSHIP PIPELINE!!!! ')
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Reading records for LS_CDB_PARTY_RELATIONSHIP '
                                                                  'pipeline from Kafka_HDFS ')

        try:
            record_from_kafka_hdfs = spark.read.json(path_kafka_hdfs)
            if debug == 1: record_from_kafka_hdfs.show(5, truncate=False)
            cnt = record_from_kafka_hdfs.count()
        except: cnt = 0

        if cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Input file either isn't available or no records")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ABORT',"File doesn't exists or 0 records available, aborting the process")
            exit(0)
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(cnt) + "' records")

        ## Gathering the MongoDB information
        db_url, db_database = getMongoDBConfiguration()

        ## Fetching records for First table
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching '"+kafka_source_topic_cust_cust_rel+"' records")
        try:
            cust_cust_rel_df = record_from_kafka_hdfs.select("CUSTOMER_ID_1","CUSTOMER_ID_2","SRC_SYS_ID",
                 "SRC_SYS_INST_ID","SRC_EVT_TYP_FLG","SRC_EXTRACT_TS","REL_TYPE","DATE_CREATED").\
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_cust_cust_rel)
            cc_rel_cnt=cust_cust_rel_df.count()
        except:cc_rel_cnt=0

        if cc_rel_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't Customer Relation records available")
            # print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '"+str(cc_rel_cnt)+"' Customer Relation records")
            if debug == 1: cust_cust_rel_df.show(5, truncate=False)
            for col in cust_cust_rel_df.columns:
                cust_cust_rel_df = cust_cust_rel_df.withColumnRenamed(col, col.lower())
            cust_cust_rel_df.createOrReplaceTempView("cust_cust_rel_tbl")

        ## Fetching records for Second table
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching "+kafka_source_topic_tcwcrx1_crel_ext1+" records")
        try:
            tcwcrx1_crel_ext1 = record_from_kafka_hdfs.select("CUSTOMER_ID_1","CUSTOMER_ID_2","SRC_SYS_ID",
                  "SRC_SYS_INST_ID","SRC_EVT_TYP_FLG","SRC_EXTRACT_TS","REL_TYPE","LAST_UPD_TIMESTAMP","BUSINESS_OWNERSHIP_PC").filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwcrx1_crel_ext1)
            tab_2_cnt = tcwcrx1_crel_ext1.count()
        except:tab_2_cnt=0

        if tab_2_cnt <= 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't any tcwcrx1_crel_ext1 records available")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '"+str(tab_2_cnt)+"' tcwcrx1_crel_ext1 records")
            if debug == 1: tcwcrx1_crel_ext1.show(5, truncate=False)
            for col in tcwcrx1_crel_ext1.columns:
                tcwcrx1_crel_ext1 = tcwcrx1_crel_ext1.withColumnRenamed(col, col.lower())

            tcwcrx1_crel_ext1.createOrReplaceTempView("tcwcrx1_crel_ext1_tbl")

        rec_stts=0
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Identifying valid records between 2 sources")

        ## When only left table has records but not right table
        if cc_rel_cnt > 0 and tab_2_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Data available only from Table_1")
            party_relationship_df = spark.sql("""SELECT DISTINCT customer_id_1, customer_id_2, src_sys_id, src_sys_inst_id, src_evt_typ_flg, 
                to_timestamp(src_extract_ts, "yyyy-MM-dd't'HH:mm:ss") as src_extract_ts, 
                rel_type, to_timestamp(date_created, "yyyy-MM-dd") as date_created, '' as business_ownership_pc 
                from cust_cust_rel_tbl where customer_id_1 is not null and customer_id_2 is not null 
                order by src_extract_ts  """)
            rec_stts = 1

        #When both tables has valid recods
        elif cc_rel_cnt > 0 and tab_2_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Data is available from both tables & identifying valid records")
            party_relationship_df_1 = spark.sql("""SELECT A.* FROM (
            select distinct ccr.customer_id_1, ccr.customer_id_2, ccr.src_sys_id, ccr.src_sys_inst_id, ccr.rel_type, 
                        coalesce(ext1.src_evt_typ_flg, ccr.src_evt_typ_flg) as src_evt_typ_flg, 
                        to_timestamp(coalesce(ext1.src_extract_ts, ccr.src_extract_ts), "yyyy-MM-dd't'HH:mm:ss") as src_extract_ts, 
                        ext1.business_ownership_pc, to_timestamp(ccr.date_created, "yyyy-MM-dd") as date_created  
                    from cust_cust_rel_tbl ccr 
                    left outer join tcwcrx1_crel_ext1_tbl ext1
                        on  ext1.customer_id_1 = ccr.customer_id_1  and ext1.customer_id_2 = ccr.customer_id_2
                        and ext1.rel_type = ccr.rel_type            and ext1.src_sys_id = ccr.src_sys_id
                        and ext1.src_sys_inst_id = ccr.src_sys_inst_id) a 
                where customer_id_1 is not null and customer_id_2 is not null 
                order by src_extract_ts
                    
                    """)
            try:rel_df_1_cnt = party_relationship_df_1.count()
            except: rel_df_1_cnt=0
            if rel_df_1_cnt > 0 :
                print("Found '" + str(rel_df_1_cnt) + "' valid records from Table_1 & Table_2 join")
                if debug == 1: party_relationship_df_1.show(5, truncate=False)

            ## Extracting the unmatched records from second table to refer Driver match
            # if cc_rel_cnt != tab_2_cnt or cc_rel_cnt != rel_df_1_cnt:
            print("Tbl_1 count: "+str(cc_rel_cnt)+", Tab_2 count: "+str(tab_2_cnt))
            print("Checking if there are any Table_2 unmatched records available.")
            try:
                unMatch_df = tcwcrx1_crel_ext1.join(party_relationship_df_1, on=['customer_id_1','customer_id_2',
                                 'src_sys_id', 'src_sys_inst_id', 'rel_type'], how='left_anti')
                unMatch_df = unMatch_df.drop('last_upd_timestamp')
                unMatch_cnt = unMatch_df.count()
                if debug == 1: unMatch_df.show(5, truncate=False)
            except:unMatch_cnt=0
            if unMatch_cnt > 0:
                print("There are '"+str(unMatch_cnt)+"' unmatched records available.")
                print("Verifying driver table for any records to match.")
                party_relationship_df_2 = generateMongoPipelineData(spark, unMatch_df)
                try: rel_df_2_cnt = party_relationship_df_2.count()
                except: rel_df_2_cnt = 0
                if rel_df_2_cnt > 0:
                    print("Obtained '"+str(rel_df_2_cnt)+"' matched records from driver collection")
                    if debug == 1:
                        print("Printing the driver matched records")
                        party_relationship_df_2.show(5, truncate=False)
                    party_relationship_df_2_1 = party_relationship_df_2.drop("_id").withColumn("date_created", lit(''))
                    if debug == 1: party_relationship_df_2_1.show()

                    print("Merging Matched & Driver_matched records together")
                    party_relationship_df = party_relationship_df_1.union(party_relationship_df_2_1)
                    if debug == 1: party_relationship_df.show()
                else: party_relationship_df = party_relationship_df_1
            else: party_relationship_df = party_relationship_df_1
            rec_stts = 1
        ## Where there are no left records but has only right table records
        elif cc_rel_cnt <= 0 and tab_2_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" :: Data is available only from Table_2, refering Driver table")
            party_relationship_df = generateMongoPipelineData(spark, tcwcrx1_crel_ext1)
            try: cnt = party_relationship_df.count()
            except: cnt=0
            if cnt > 0: party_relationship_df = party_relationship_df.drop("_id")
            rec_stts = 1
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't any valid records available")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ABORT',
                                         "There aren't any valid  records available, aborting the process")
            exit(1)

        try:
            ## Checking if there is data resulted from above steps or not
            cnt=0
            if rec_stts == 1: cnt = party_relationship_df.count()
        except: cnt=0
        if cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't any valid records available")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ABORT',
                                         "There aren't any valid  records available, aborting the process")
            exit(1)
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are '"+str(cnt)+"' record(s) available from valid data")
            party_relationship_df.show(5, truncate=False)

        party_relationship_df = party_relationship_df.na.fill("")

        ##Processing data for INSERTS & UPDATE/DELETES records
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing records for IN or UP/DL data")
        kafka_data = handle_status_flag(spark, party_relationship_df)
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed processing records for IN or UP/DL data")

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Creating Topic Name LS key for Kafka")
        party_relationship_df = kafka_data.withColumn("SRC_LS_MAP", lit(kafka_topic))
        party_relationship_df = party_relationship_df.withColumn("value", to_json(
            struct([party_relationship_df[x] for x in party_relationship_df.columns])))
        if debug == 1: party_relationship_df.show(5, truncate=False)

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing final data to kafka: "+kafka_topic)
        produce_on_kafka(party_relationship_df, kafka_topic)
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS', 'File Processed')

    except ParseException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryParserError', str(ex))
    except QueryExecutionException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))
    except AnalysisException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'DataFrameError', str(ex))
    except KafkaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))
    except MongoException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'MongoError', str(ex.getmessage()))
    except Py4JJavaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'GeneralError',
                                     ex.java_exception.toString())


# ##################################################### UTILITIES ##############################################################################################

def generateMongoPipelineData(spark, df):
    try:
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Creating pipeline to fetch data from driver collection.")

        pp_cols_df = df.select("customer_id_1", "customer_id_2", "src_sys_id", "src_sys_inst_id", "rel_type")
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating pipeline for unmatched records")
        pipeline = "[{ $project: {_id: 0, customer_id_1:1, customer_id_2:1, src_sys_id:1, src_sys_inst_id:1, rel_type:1}}," \
                   "{'$match': {'customer_id_1':{$in: " + str(
            [int(i.customer_id_1) for i in df.select('customer_id_1').collect()]) + "}}}]"

        if debug == 1: print(
            str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: pipeline:\n" + pipeline)
        try:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Executing pipeline on MongoDB")
            drv_cust_rel_df = read_from_mongo_pipeline(spark, mongo_driver_cust_rel_collection, pipeline)
            drv_cust_rel_cnt = drv_cust_rel_df.count()
        except: drv_cust_rel_cnt = 0
        if drv_cust_rel_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" :: Found reference data from Driver collection on MongoDB")
            if debug == 1: drv_cust_rel_df.show(5, truncate=False)
            # df = df.withColumn('DATE_CREATED', lit(''))
            results_df = df.join(drv_cust_rel_df, on=['customer_id_1', 'customer_id_2', 'src_sys_id','src_sys_inst_id', 'rel_type'], how='inner')

            # try: cnt = results_df.count()
            # except: cnt=0
            return results_df
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Driver collection has no reference data")
            return drv_cust_rel_df
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())


## Processing INSERT or UPDATE/DELETE records
def processIN_UPDLRecords(spark, df, dmlStr):
    try:
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Processing " + dmlStr + " records through MongoDB Pipeline.")
        if debug == 1: df.show(10, truncate=False)

        pp_cols_df = df.select("customer_id_1", "customer_id_2", "src_sys_id", "src_sys_inst_id", "rel_type").distinct()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating pipeline for unmatched records")
        pipeline = "[{ $project: {_id: 1, customer_id_1:1, customer_id_2:1, src_sys_id:1, src_sys_inst_id:1, rel_type:1}}," \
                   "{'$match': {'customer_id_1':{$in: " + str(
            [int(i.customer_id_1) for i in df.select('customer_id_1').collect()]) + "}}}]"

        if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: pipeline:\n" + pipeline + "\n")
        try:
            print(str(datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')) + " :: Processing the pipeline on MongoDB to fetch the matching data")
            pp_res_df = read_from_mongo_pipeline(spark, mongo_write_collection, pipeline)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed executing pipeline on MongoDB")
            if debug == 1: pp_res_df.show(5, truncate=False)
            pp_res_cnt = pp_res_df.count()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Obtained '" + str(
                pp_res_cnt) + "' data from MongoDB pipeline")

        except: pp_res_cnt = 0

        ## If MongoDB is empty, there will be 0 records returned/matched with pipeline
        if pp_res_cnt <= 0 and dmlStr == str('INSERT'):
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: All the " + dmlStr + " records are new ones")
            final_df = df
            try:
                fin_cnt = final_df.count()
                if debug == 1: final_df.show(2, truncate=False)
            except: fin_cnt = 0
        else:
            try:
                print(str(datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S')) + " :: Processing " + dmlStr + " records to find driver match")
                final_df = df.join(pp_res_df,
                                   on=['customer_id_1', 'customer_id_2', 'src_sys_id', 'src_sys_inst_id', 'rel_type'],
                                   how='left_outer').distinct()
                fin_cnt = final_df.count()
            except: fin_cnt = 0

        if fin_cnt == 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't any valid " + dmlStr + " records present")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(fin_cnt) + "' " + dmlStr + " records")
            if debug == 1: final_df.show(10, truncate=False)
            write_to_mongo(final_df, mongo_write_collection)
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS', 'Data written to MongoDB')
            try: id_cnt = final_df.select("_id").count()
            except: id_cnt = 0
            if id_cnt > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Ignoring _id field for kafka data")
                final_df = final_df.drop("_id")
        if debug == 1: final_df.show(5, truncate=False)
        return final_df

    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())


def handle_status_flag(spark, df):
    try:

        ##Handle INSERT records
        ##1. Write only NEW INSERT records to Mongo that doesn't have match at target
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Identiying IN records if available.")
        try:
            IN_df = df.filter(df['src_evt_typ_flg'] == "IN")
            IN_cnt = IN_df.count()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: IN Records count: " + str(IN_cnt))
            if debug == 1: IN_df.show(5, truncate=False)
        except:
            IN_cnt = 0

        if IN_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: IN records aren't available.")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(IN_cnt) + "' IN records.")

            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing data for IN records.")
            Kafka_IN_df = processIN_UPDLRecords(spark, IN_df, "INSERT")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed processing IN records.")
            if debug == 1: Kafka_IN_df.show()

        ##Handle UPDATE/DELETE records
        ##2. Write UPDATE records to Mongo applying UPDATE process
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Initiating  UP/DL records.")
        try:
            UP_df = df.filter((df['src_evt_typ_flg'] == "UP") | (df['src_evt_typ_flg'] == "DL"))
            UP_cnt = UP_df.count()
        except:
            UP_cnt = 0
        if UP_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are '" + str(
                UP_cnt) + "'  UP/DL records to process")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing data for UP/DL records.")
            Kafka_UPDL_df = processIN_UPDLRecords(spark, UP_df, "UP/DL")
            try:
                updl_cnt = Kafka_UPDL_df.count()
            except:
                updl_cnt = 0
            if debug == 1: Kafka_UPDL_df.show()
            if updl_cnt > 0: Kafka_UPDL_df = Kafka_UPDL_df.drop("_id")
            if debug == 1: Kafka_UPDL_df.show()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed UP/DL records.")

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Merging records on availability")
        if IN_cnt > 0 and UP_cnt > 0: kafka_df = Kafka_IN_df.union(Kafka_UPDL_df)
        elif IN_cnt > 0 and UP_cnt <= 0: kafka_df = Kafka_IN_df
        elif IN_cnt <= 0 and UP_cnt > 0: kafka_df = Kafka_UPDL_df
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found no valid IN or UP/DL records.")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'FAILURE', 'Found no valid IN or UP/DL records')

        return kafka_df

    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())


def read_from_mongo(spark, collection, pipeline):
    try:
        global db_url, db_database
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + ":: Loaded Source Collection: " + collection + " from MongoDB ")
        return df
    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def read_from_mongo_pipeline(spark, collection, pipeline):
    try:
        global db_url, db_database;
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        global db_url, db_database
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', True) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ":: Written CDB E-ADDRESS Logical Source "
                                                                  "Data in MongoDB collection: " + mongo_write_collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def produce_on_kafka(df, topic_name):
    try:
        df.selectExpr("CAST(value as STRING)"). \
            write. \
            format("kafka"). \
            option("kafka.bootstrap.servers", kafka_bootstrap_server). \
            option("topic", topic_name). \
            save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Produced records on Kafka Topic: " + kafka_topic)
    except Py4JJavaError as ex:
        raise KafkaError(ex.java_exception.toString())


def getMongoDBConfiguration():
    try:
        config = configparser.ConfigParser()
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        raise ex


def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ods_ls_cdb_ind_relationship","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex


if __name__ == '__main__':
    main()