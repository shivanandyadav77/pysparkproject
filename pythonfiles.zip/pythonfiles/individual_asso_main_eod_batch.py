__author__ = "vermanx"
# Filename: individual_asso_main.py
# Mapping: m_CDB_LS_Party_Individual
# TRN_NME: LS_CDB_INDIVIDUAL_ASSO
#
# Source/Target details:
# Input : STREAMING.CDB.CUSTOMER-PORTFOLIO.STD, STREAMING.CDB.PERSONAL-CUSTOMER.STD, STREAMING.CDB.PORTFOLIO-DETAILS.STD, STREAMING.CDB.TCWDISC-DISAB-CUST.STD, STREAMING.CDB.TCWPEX1-PCUS-EXT1.STD, STREAMING.CDB.TCWPPSN-PPS-NUM.STD, STREAMING.CDB.TCWSCVW-SCV.STD
# Output: Mongo Collection- LS_CDB_INDIVIDUAL_ASSO; Kafka Topic- STREAMING.CDB.INDIVIDUAL-ASSO.LDM

# INDIVIDUAL ASSOCIATION

# ################################################################################################################################################################################
from pyspark.sql.functions import to_json, struct, concat, lit
import pyspark
from pyspark.sql.types import *

from py4j.protocol import Py4JJavaError
from pyspark.sql import SparkSession
import sys
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser

import  os
from datetime import datetime

from pyspark.sql.utils import QueryExecutionException
from pyspark.sql.utils import AnalysisException
from pyspark.sql.utils import ParseException

class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message


class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message


# Variables populated at runtime


path_kafka_hdfs = sys.argv[1]
mongo_write_collection = sys.argv[2]
kafka_bootstrap_server = sys.argv[3]
kafka_source_topic_customer_portfolio = sys.argv[4]
kafka_source_topic_personal_customer = sys.argv[5]
kafka_source_topic_portfolio_details = sys.argv[6]
kafka_source_topic_tcwdisc_disab_cust = sys.argv[7]
kafka_source_topic_tcwpex1_pcus_ext1 = sys.argv[8]
kafka_source_topic_tcwppsn_pps_num = sys.argv[9]
kafka_source_topic_tcwscvw_scv = sys.argv[10]
mongo_driver_collection = sys.argv[11]
columndata = sys.argv[12]


# ################################################################################################################################################################################


def main():
    try:
        print('file location::'+path_kafka_hdfs)
        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        # spark.conf.set("spark.debug.maxToStringFields", 1000)
        # print('length::'+spark.conf.get("spark.debug.maxToStringFields"))





        # spark = SparkSession.builder.config("spark.sql.warehouse.dir", u'hdfs:///user/spark/warehouse').getOrCreate()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: SPARK SESSION INITIALIZED. STARTING '
                                                                  'LS_CDB_INDIVIDUAL_ASSO PIPELINE!!!! ')
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Reading records for LS_CDB_INDIVIDUAL_ASSO '
                                                                  'pipeline from Kafka_HDFS ')

        try:
            columndata_df = spark.read.json(columndata)
        except Py4JJavaError as ex:
            writeApplicationStatusToFile(path_kafka_hdfs, 'GeneralError',ex.java_exception.toString())
            exit(0)
        record_from_kafka_hdfs = spark.read.json( path_kafka_hdfs)

        try:
            personal_customer_df = record_from_kafka_hdfs.select("ACCESS_HOLDER_IND", "ACCES_GOLD_HLD_IND",
                                                                 "ALL_PROD_MAIL_IND", "ALL_PROD_MAIL_UPDT",
                                                                 "AMEX_GOLD_HOLD_IND", "AMEX_GREEN_HLD_IND",
                                                                 "BANK_ID",
                                                                 "BUSINESS_PHONE_NO", "BUS_PHONE_NO_UPDT",
                                                                 "CAR_OWNER_IND", "B_SOC_CC_ACC_IND",
                                                                 "CHANNEL_ATM_IND", "B_SOC_SAVINGS_IND",
                                                                 "CHANNEL_BRANCH_IND",
                                                                 "CHANNEL_INET_IND", "B_SOC_MORTGAGE_IND",
                                                                 "CHANNEL_PHONE_IND",
                                                                 "CHNGE_DT_PREV_BUS", "CHNGE_DT_PREV_HOME",
                                                                 "CHNGE_DT_PREV_MOB", "CONTACT_PERIOD_CD",
                                                                 "COURSE_START_DATE", "CREDIT_GRADE",
                                                                 "CREDIT_GRADE_DATE", "CREDIT_RESP_IND",
                                                                 "CRED_CARD_MAIL_IND", "CRT_ISSUING_CTRY",
                                                                 "CTRY_OF_BIRTH", "CTRY_OF_NATIONALTY",
                                                                 "CTRY_OF_RESIDENCE", "CUSTOMER_ADDRESSEE",
                                                                 "CUSTOMER_ADDR_NO", "CUSTOMER_DOB",
                                                                 "CUSTOMER_FIRST_NAM", "CUSTOMER_FORENAM_1",
                                                                 "CUSTOMER_FORENAM_2", "CUSTOMER_FORENAM_3",
                                                                 "CUSTOMER_GENDER", "CUSTOMER_ID", "CUSTOMER_NAME_KEY",
                                                                 "CUSTOMER_NAME_SFX", "CUSTOMER_OWNED_BY",
                                                                 "CUSTOMER_SALUTATN", "CUSTOMER_SRC_TYPE",
                                                                 "CUSTOMER_STATUS", "CUSTOMER_SURNAME",
                                                                 "CUSTOMER_TITLE", "CUST_PROGRESS_IND",
                                                                 "DECEASED_DATE", "DEPEND_CHILD_CNT",
                                                                 "DINERS_HOLDER_IND", "DPA_CONSENT_MARKER",
                                                                 "EMAIL_ADDRESS", "EMAIL_IND", "EMAIL_IND_UPDT",
                                                                 "FINPIN_CLASS_10", "FINPIN_CLASS_4", "FINPIN_CLASS_40",
                                                                 "FIRST_CONTACT_DATE", "GRADUATION_DATE",
                                                                 "HIGH_NET_WORTH_IND", "HIGH_VAL_PROD_MAIL",
                                                                 "HOME_OWNER_IND", "HOME_PHONE_NO",
                                                                 "HOME_PHONE_NO_UPDT", "INSURANCE_PROD_IND",
                                                                 "LAST_CHNG_DATE", "LAST_CONT_SAT_DATE",
                                                                 "LAST_CONT_SAT_RATE", "MOBILE_PHONE_NO",
                                                                 "MOB_PHONE_NO_UPDT", "MORT_EQU_REL_MAIL",
                                                                 "NATIONAL_INS_NO", "NON_RBS_ACCESS_IND",
                                                                 "NON_RBS_AX_GLD_IND", "NON_RBS_MASTER_IND",
                                                                 "NON_RBS_VISA_IND", "NO_MAIL_IND", "OCCUPATION_CODE",
                                                                 "OCCUPATION_DESC", "OTHER_BANK_SAV_IND",
                                                                 "OTHER_BNK_MORT_IND", "OTHER_CARD_HLD_IND",
                                                                 "OTHER_GOLD_IND", "O_BANK_CC_ACC_IND", "PASSPORT_CTRY",
                                                                 "PASSPORT_EXP_DATE", "PASSPORT_NO",
                                                                 "PERSONAL_UPT_COUNT", "PER_CRED_PROD_IND", "PHONE_IND",
                                                                 "PHONE_IND_UPDT", "PLACE_OF_BIRTH",
                                                                 "POTENTIAL_PROVISN", "PREF_PHONE_NO_IND",
                                                                 "PREV_BUS_PHONE_NO", "PREV_HOME_PHONE_NO",
                                                                 "PREV_MOB_PHONE_NO", "PRIVATE_BANK_IND", "PROMPT_IND",
                                                                 "PROMPT_IND_UPDT", "RBS_ACCESS_IND",
                                                                 "RBS_AMEX_GOLD_IND", "RBS_MASTERCARD_IND",
                                                                 "RBS_MAST_GOLD_IND", "RBS_VISA_GOLD_IND",
                                                                 "RBS_VISA_IND", "RISK_RATING", "RT_IND",
                                                                 "SAVS_PROD_MAIL_IND",
                                                                 "SEGMENT_CODE", "SEG_CODE_DATE",
                                                                 "SHADOW_LIMIT", "SHADOW_LIMIT_IND", "SHAREHOLDER_IND",
                                                                 "SMS_IND", "SMS_IND_UPDT",
                                                                 "SPECIAL_CREDT_IND", "SRC_EVT_TYP_FLG",
                                                                 "SRC_EXTRACT_TS", "SRC_SYS_ID",
                                                                 "SRC_SYS_INST_ID", "STYLE_HOLDER_IND", "TAX_NUMBER",
                                                                 "TRAVEL_PROD_MAIL", "UNIT_TRUST_HLD_IND",
                                                                 "VISA_HOLDER_IND", "WAIVE_EXPIRY_DATE",
                                                                 "WAIVE_REASON_CODE").filter(
            record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_personal_customer)
        except AnalysisException as ex:
            print(ex)
            personal_customer_df = getEmptyDataFrame(columndata_df, kafka_source_topic_personal_customer).select("ACCESS_HOLDER_IND", "ACCES_GOLD_HLD_IND",
                                                                 "ALL_PROD_MAIL_IND", "ALL_PROD_MAIL_UPDT",
                                                                 "AMEX_GOLD_HOLD_IND", "AMEX_GREEN_HLD_IND",
                                                                 "BANK_ID",
                                                                 "BUSINESS_PHONE_NO", "BUS_PHONE_NO_UPDT",
                                                                 "CAR_OWNER_IND", "B_SOC_CC_ACC_IND",
                                                                 "CHANNEL_ATM_IND", "B_SOC_SAVINGS_IND",
                                                                 "CHANNEL_BRANCH_IND",
                                                                 "CHANNEL_INET_IND", "B_SOC_MORTGAGE_IND",
                                                                 "CHANNEL_PHONE_IND",
                                                                 "CHNGE_DT_PREV_BUS", "CHNGE_DT_PREV_HOME",
                                                                 "CHNGE_DT_PREV_MOB", "CONTACT_PERIOD_CD",
                                                                 "COURSE_START_DATE", "CREDIT_GRADE",
                                                                 "CREDIT_GRADE_DATE", "CREDIT_RESP_IND",
                                                                 "CRED_CARD_MAIL_IND", "CRT_ISSUING_CTRY",
                                                                 "CTRY_OF_BIRTH", "CTRY_OF_NATIONALTY",
                                                                 "CTRY_OF_RESIDENCE", "CUSTOMER_ADDRESSEE",
                                                                 "CUSTOMER_ADDR_NO", "CUSTOMER_DOB",
                                                                 "CUSTOMER_FIRST_NAM", "CUSTOMER_FORENAM_1",
                                                                 "CUSTOMER_FORENAM_2", "CUSTOMER_FORENAM_3",
                                                                 "CUSTOMER_GENDER", "CUSTOMER_ID", "CUSTOMER_NAME_KEY",
                                                                 "CUSTOMER_NAME_SFX", "CUSTOMER_OWNED_BY",
                                                                 "CUSTOMER_SALUTATN", "CUSTOMER_SRC_TYPE",
                                                                 "CUSTOMER_STATUS", "CUSTOMER_SURNAME",
                                                                 "CUSTOMER_TITLE", "CUST_PROGRESS_IND",
                                                                 "DECEASED_DATE", "DEPEND_CHILD_CNT",
                                                                 "DINERS_HOLDER_IND", "DPA_CONSENT_MARKER",
                                                                 "EMAIL_ADDRESS", "EMAIL_IND", "EMAIL_IND_UPDT",
                                                                 "FINPIN_CLASS_10", "FINPIN_CLASS_4", "FINPIN_CLASS_40",
                                                                 "FIRST_CONTACT_DATE", "GRADUATION_DATE",
                                                                 "HIGH_NET_WORTH_IND", "HIGH_VAL_PROD_MAIL",
                                                                 "HOME_OWNER_IND", "HOME_PHONE_NO",
                                                                 "HOME_PHONE_NO_UPDT", "INSURANCE_PROD_IND",
                                                                 "LAST_CHNG_DATE", "LAST_CONT_SAT_DATE",
                                                                 "LAST_CONT_SAT_RATE", "MOBILE_PHONE_NO",
                                                                 "MOB_PHONE_NO_UPDT", "MORT_EQU_REL_MAIL",
                                                                 "NATIONAL_INS_NO", "NON_RBS_ACCESS_IND",
                                                                 "NON_RBS_AX_GLD_IND", "NON_RBS_MASTER_IND",
                                                                 "NON_RBS_VISA_IND", "NO_MAIL_IND", "OCCUPATION_CODE",
                                                                 "OCCUPATION_DESC", "OTHER_BANK_SAV_IND",
                                                                 "OTHER_BNK_MORT_IND", "OTHER_CARD_HLD_IND",
                                                                 "OTHER_GOLD_IND", "O_BANK_CC_ACC_IND", "PASSPORT_CTRY",
                                                                 "PASSPORT_EXP_DATE", "PASSPORT_NO",
                                                                 "PERSONAL_UPT_COUNT", "PER_CRED_PROD_IND", "PHONE_IND",
                                                                 "PHONE_IND_UPDT", "PLACE_OF_BIRTH",
                                                                 "POTENTIAL_PROVISN", "PREF_PHONE_NO_IND",
                                                                 "PREV_BUS_PHONE_NO", "PREV_HOME_PHONE_NO",
                                                                 "PREV_MOB_PHONE_NO", "PRIVATE_BANK_IND", "PROMPT_IND",
                                                                 "PROMPT_IND_UPDT", "RBS_ACCESS_IND",
                                                                 "RBS_AMEX_GOLD_IND", "RBS_MASTERCARD_IND",
                                                                 "RBS_MAST_GOLD_IND", "RBS_VISA_GOLD_IND",
                                                                 "RBS_VISA_IND", "RISK_RATING", "RT_IND",
                                                                 "SAVS_PROD_MAIL_IND",
                                                                 "SEGMENT_CODE", "SEG_CODE_DATE",
                                                                 "SHADOW_LIMIT", "SHADOW_LIMIT_IND", "SHAREHOLDER_IND",
                                                                 "SMS_IND", "SMS_IND_UPDT",
                                                                 "SPECIAL_CREDT_IND", "SRC_EVT_TYP_FLG",
                                                                 "SRC_EXTRACT_TS", "SRC_SYS_ID",
                                                                 "SRC_SYS_INST_ID", "STYLE_HOLDER_IND", "TAX_NUMBER",
                                                                 "TRAVEL_PROD_MAIL", "UNIT_TRUST_HLD_IND",
                                                                 "VISA_HOLDER_IND", "WAIVE_EXPIRY_DATE",
                                                                 "WAIVE_REASON_CODE")

        personal_customer_df.show(truncate=False)
        try:
            cdb_customer_portfolio_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "PORTFOLIO_CODE", "PFOLIO_AS_OF_DATE","SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS",
                                                                  "SRC_SYS_INST_ID", "SRC_SYS_ID") \
            .filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_customer_portfolio)
            cdb_customer_portfolio_df.show(truncate=False)
        except AnalysisException as ex:
            print(ex)
            cdb_customer_portfolio_df = getEmptyDataFrame(columndata_df, kafka_source_topic_customer_portfolio).select("CUSTOMER_ID", "PORTFOLIO_CODE", "PFOLIO_AS_OF_DATE",
                                                                  "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS",
                                                                  "SRC_SYS_INST_ID", "SRC_SYS_ID")

        cdb_customer_portfolio_df=cdb_customer_portfolio_df.withColumnRenamed('PFOLIO_AS_OF_DATE','PORTFOLIO_DATE')
        cdb_customer_portfolio_df.show(truncate=False)
        try:
            cdb_portfolio_details_df = record_from_kafka_hdfs.select("PORTFOLIO_CODE", "PFOLIO_AS_OF_DATE", "SALARY_REF_NO",
                                                                 "RM_SURNAME", "RM_FORENAME", "JOB_DESCPTN_CODE",
                                                                 "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                                 "SRC_EXTRACT_TS"). \
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_portfolio_details)
            # cdb_portfolio_details_df.show(truncate=False)
        except AnalysisException as ex:
            cdb_portfolio_details_df = getEmptyDataFrame(columndata_df, kafka_source_topic_portfolio_details).select("PORTFOLIO_CODE", "PFOLIO_AS_OF_DATE", "SALARY_REF_NO",
                                                                 "RM_SURNAME", "RM_FORENAME", "JOB_DESCPTN_CODE",
                                                                 "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                                 "SRC_EXTRACT_TS")

        cdb_portfolio_details_df = cdb_portfolio_details_df.withColumnRenamed('PORTFOLIO_CODE', 'PORTFOLIO_CODEAS')
        # cdb_portfolio_details_df.show(truncate=False)
        try:
            tcwdisc_disab_cust_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "DISABILITY_CODE",
                                                              "DISABILITY_DESC", "LAST_UPDT_TSTAMP", "SRC_SYS_ID",
                                                              "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS"). \
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwdisc_disab_cust)
        # tcwdisc_disab_cust_df.show(truncate=False)
        except AnalysisException as ex:
            tcwdisc_disab_cust_df = getEmptyDataFrame(columndata_df, kafka_source_topic_tcwdisc_disab_cust).select("CUSTOMER_ID", "DISABILITY_CODE",
                                                              "DISABILITY_DESC", "LAST_UPDT_TSTAMP", "SRC_SYS_ID",
                                                              "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS")

        # tcwdisc_disab_cust_df.show(truncate=False)
        try:
            cdb_tcwpex1_pcus_ext1_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "OTHER_LAST_NAME", "OTHER_FIRST_NAME",
                                                                 "OTHER_FORENAM_1", "OTHER_FORENAM_2",
                                                                 "OTHER_FORENAM_3",
                                                                 "CHANNEL_OF_APP", "SRC_OF_INCOME", "SRC_OF_WEALTH",
                                                                 "UPDATE_TMSTMP", "SRC_SYS_ID", "SRC_SYS_INST_ID",
                                                                 "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS"). \
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwpex1_pcus_ext1)
        # cdb_tcwpex1_pcus_ext1_df.show(truncate=False)
        except AnalysisException as ex:
            cdb_tcwpex1_pcus_ext1_df = getEmptyDataFrame(columndata_df, kafka_source_topic_tcwpex1_pcus_ext1).select("CUSTOMER_ID", "OTHER_LAST_NAME", "OTHER_FIRST_NAME",
                                                                 "OTHER_FORENAM_1", "OTHER_FORENAM_2",
                                                                 "OTHER_FORENAM_3",
                                                                 "CHANNEL_OF_APP", "SRC_OF_INCOME", "SRC_OF_WEALTH",
                                                                 "UPDATE_TMSTMP", "SRC_SYS_ID", "SRC_SYS_INST_ID",
                                                                 "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS")

        # cdb_tcwpex1_pcus_ext1_df.show(truncate=False)
        try:
            cdb_tcwppsn_pps_num_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "CUSTOMER_TYPE", "PPS_TAX_CHARITY_NO",
                                                               "VERIFICATN_STATUS", "LAST_CHNG_DATE", "UPDATE_COUNT",
                                                               "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                               "SRC_EXTRACT_TS"). \
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwppsn_pps_num)
        # cdb_tcwppsn_pps_num_df.show(truncate=False)
        except AnalysisException as ex:
            cdb_tcwppsn_pps_num_df = getEmptyDataFrame(columndata_df, kafka_source_topic_tcwppsn_pps_num).select("CUSTOMER_ID", "CUSTOMER_TYPE", "PPS_TAX_CHARITY_NO",
                                                               "VERIFICATN_STATUS", "LAST_CHNG_DATE", "UPDATE_COUNT",
                                                               "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                               "SRC_EXTRACT_TS")

        cdb_tcwppsn_pps_num_df = cdb_tcwppsn_pps_num_df.withColumnRenamed('LAST_CHNG_DATE',
                                                                                    'PPS_NUM_LAST_CHNG_DATE')

        # cdb_tcwppsn_pps_num_df.show(truncate=False)
        try:
            cdb_tcwscvw_scv_df = record_from_kafka_hdfs.select("SOURCE_SYSTEM", "CUSTOMER_IDENT", "GURN", "BRAND_ID",
                                                           "CUSTOMER_TYPE", "SRC_SYS_ID", "SRC_SYS_INST_ID",
                                                           "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS"). \
            filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwscvw_scv)
        # cdb_tcwscvw_scv_df.show(truncate=False)
        except AnalysisException as ex:
            cdb_tcwscvw_scv_df = getEmptyDataFrame(columndata_df, kafka_source_topic_tcwscvw_scv).select("SOURCE_SYSTEM", "CUSTOMER_IDENT", "GURN", "BRAND_ID",
                                                           "CUSTOMER_TYPE", "SRC_SYS_ID", "SRC_SYS_INST_ID",
                                                           "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS")

        cdb_tcwscvw_scv_df = cdb_tcwscvw_scv_df.withColumnRenamed('CUSTOMER_IDENT', 'CUSTOMER_ID')
        # cdb_tcwscvw_scv_df.show(truncate=False)
        cdb_tcwpex1_pcus_ext1_df.show(truncate=False)
        print('------cdb_customer_portfolio_df-------start')
        for col in personal_customer_df.columns:
            personal_customer_df = personal_customer_df.withColumnRenamed(col, col.lower())
        for col in cdb_customer_portfolio_df.columns:
            cdb_customer_portfolio_df = cdb_customer_portfolio_df.withColumnRenamed(col, col.lower())
        for col in cdb_tcwscvw_scv_df.columns:
            cdb_tcwscvw_scv_df = cdb_tcwscvw_scv_df.withColumnRenamed(col, col.lower())
        for col in cdb_tcwppsn_pps_num_df.columns:
            cdb_tcwppsn_pps_num_df = cdb_tcwppsn_pps_num_df.withColumnRenamed(col, col.lower())
        for col in cdb_tcwpex1_pcus_ext1_df.columns:
            cdb_tcwpex1_pcus_ext1_df = cdb_tcwpex1_pcus_ext1_df.withColumnRenamed(col, col.lower())
        for col in tcwdisc_disab_cust_df.columns:
            tcwdisc_disab_cust_df = tcwdisc_disab_cust_df.withColumnRenamed(col, col.lower())
        for col in cdb_portfolio_details_df.columns:
            cdb_portfolio_details_df = cdb_portfolio_details_df.withColumnRenamed(col, col.lower())

        cdb_customer_portfolio_df.show(truncate=False)
        cdb_customer_portfolio_df.createOrReplaceTempView("cdb_customer_portfolio_tbl")
        cdb_tcwscvw_scv_df.createOrReplaceTempView("tcwscvw_scv_tbl")
        cdb_tcwppsn_pps_num_df.createOrReplaceTempView("tcwppsn_pps_num_tbl")
        cdb_tcwpex1_pcus_ext1_df.createOrReplaceTempView("tcwpex1_pcus_ext1_tbl")
        tcwdisc_disab_cust_df.createOrReplaceTempView("tcwdisc_disab_cust_tbl")
        cdb_portfolio_details_df.createOrReplaceTempView("cdb_portfolio_details_tbl")
        custtemp_df = getUnion(spark, cdb_customer_portfolio_df, cdb_tcwscvw_scv_df, cdb_tcwppsn_pps_num_df,
                               cdb_tcwpex1_pcus_ext1_df, tcwdisc_disab_cust_df, cdb_portfolio_details_df)

        personalcustomer_df = getcombineall(spark, personal_customer_df, custtemp_df)
        personalcustomer_df = personalcustomer_df.dropDuplicates()

        if personalcustomer_df.count() == 0:
            exit(0)

        personalcustomer_df.createOrReplaceTempView("cdb_personal_customer_tbl")
        individual_df = spark.sql("""select cdb_personal_customer.record_status,
                      coalesce(cdb_customer_portfolio.src_evt_typ_flg,  
                      coalesce(cdb_tcwdisc_disab_cust.src_evt_typ_flg, 
                      coalesce(tcwscvw_scv.src_evt_typ_flg, 
                      coalesce(tcwpex1.src_evt_typ_flg, 
                      coalesce(cdb_portfolio_details.src_evt_typ_flg, 
                      coalesce(cdb_tcwppsn_pps_num.src_evt_typ_flg, 
                      cdb_personal_customer.src_evt_typ_flg)))))) as src_evt_typ_flg,         
                      to_timestamp(  coalesce(cdb_customer_portfolio.src_extract_ts,          
                      coalesce(cdb_tcwdisc_disab_cust.src_extract_ts, 
                      coalesce(tcwscvw_scv.src_extract_ts, 
                      coalesce(tcwpex1.src_extract_ts, 
                      coalesce(cdb_portfolio_details.src_extract_ts, 
                      coalesce(cdb_tcwppsn_pps_num.src_extract_ts, 
                      cdb_personal_customer.src_extract_ts)))))) , "yyyy-mm-dd't'hh:mm:ss") as src_extract_ts,        
                      cdb_personal_customer.src_sys_id, cdb_personal_customer.src_sys_inst_id, cdb_personal_customer.customer_id, 
                      cdb_personal_customer.customer_title, cdb_personal_customer.customer_surname, 
                      cdb_personal_customer.customer_first_nam, cdb_personal_customer.customer_forenam_1, 
                      cdb_personal_customer.customer_forenam_2, cdb_personal_customer.customer_forenam_3, 
                      cdb_personal_customer.customer_name_sfx, cdb_personal_customer.customer_salutatn, 
                      cdb_personal_customer.customer_src_type, cdb_personal_customer.customer_gender, 
                      cdb_personal_customer.customer_status, to_timestamp(cdb_personal_customer.customer_dob, "yyyy-mm-dd") as 
                      customer_dob, cdb_personal_customer.home_phone_no, cdb_personal_customer.business_phone_no, 
                      cdb_personal_customer.depend_child_cnt, cdb_personal_customer.finpin_class_4, 
                      cdb_personal_customer.finpin_class_10, cdb_personal_customer.finpin_class_40, 
                      cdb_personal_customer.home_owner_ind, cdb_personal_customer.access_holder_ind, 
                      cdb_personal_customer.acces_gold_hld_ind, cdb_personal_customer.visa_holder_ind, 
                      cdb_personal_customer.amex_green_hld_ind, cdb_personal_customer.amex_gold_hold_ind, 
                      cdb_personal_customer.diners_holder_ind, cdb_personal_customer.style_holder_ind, 
                      cdb_personal_customer.other_card_hld_ind, cdb_personal_customer.b_soc_savings_ind, 
                      cdb_personal_customer.b_soc_mortgage_ind, cdb_personal_customer.shareholder_ind, 
                      cdb_personal_customer.unit_trust_hld_ind, cdb_personal_customer.car_owner_ind, 
                      cdb_personal_customer.occupation_desc, cdb_personal_customer.occupation_code, 
                      to_timestamp(cdb_personal_customer.first_contact_date, "yyyy-mm-dd") as first_contact_date, 
                      cdb_personal_customer.customer_addr_no, cdb_personal_customer.customer_name_key, 
                      cdb_personal_customer.no_mail_ind, to_timestamp(cdb_personal_customer.deceased_date, "yyyy-mm-dd") as 
                      deceased_date, to_timestamp(cdb_personal_customer.last_chng_date, "yyyy-mm-dd") as last_chng_date, 
                      cdb_personal_customer.personal_upt_count, 
                      cdb_personal_customer.rbs_access_ind, cdb_personal_customer.rbs_mast_gold_ind, 
                      cdb_personal_customer.rbs_visa_ind, cdb_personal_customer.rbs_amex_gold_ind, 
                      cdb_personal_customer.all_prod_mail_ind, cdb_personal_customer.national_ins_no, 
                      cdb_personal_customer.high_net_worth_ind, cdb_personal_customer.non_rbs_access_ind, 
                      cdb_personal_customer.non_rbs_visa_ind, cdb_personal_customer.rbs_mastercard_ind, 
                      cdb_personal_customer.non_rbs_master_ind, cdb_personal_customer.rbs_visa_gold_ind, 
                      cdb_personal_customer.non_rbs_ax_gld_ind, cdb_personal_customer.other_gold_ind, 
                      cdb_personal_customer.other_bank_sav_ind, cdb_personal_customer.other_bnk_mort_ind, 
                      cdb_personal_customer.o_bank_cc_acc_ind, cdb_personal_customer.b_soc_cc_acc_ind, 
                      cdb_personal_customer.per_cred_prod_ind, cdb_personal_customer.cred_card_mail_ind, 
                      cdb_personal_customer.mort_equ_rel_mail, cdb_personal_customer.savs_prod_mail_ind, 
                      cdb_personal_customer.high_val_prod_mail, cdb_personal_customer.insurance_prod_ind, 
                      cdb_personal_customer.travel_prod_mail, cdb_personal_customer.customer_addressee, 
                      cdb_personal_customer.credit_grade, to_timestamp(cdb_personal_customer.credit_grade_date, "yyyy-mm-dd") as 
                      credit_grade_date, cdb_personal_customer.potential_provisn, cdb_personal_customer.waive_reason_code, 
                      to_timestamp(cdb_personal_customer.waive_expiry_date, "yyyy-mm-dd") as waive_expiry_date, 
                      cdb_personal_customer.credit_resp_ind, cdb_personal_customer.shadow_limit_ind, 
                      cdb_personal_customer.special_credt_ind, cdb_personal_customer.shadow_limit, 
                      cdb_personal_customer.risk_rating, cdb_personal_customer.bank_id, 
                      to_timestamp(cdb_personal_customer.course_start_date, "yyyy-mm-dd") as course_start_date, 
                      to_timestamp(cdb_personal_customer.graduation_date, "yyyy-mm-dd") as graduation_date, 
                      cdb_personal_customer.private_bank_ind, cdb_personal_customer.segment_code, 
                      to_timestamp(cdb_personal_customer.seg_code_date, "yyyy-mm-dd") as seg_code_date, 
                      cdb_personal_customer.customer_owned_by, cdb_personal_customer.ctry_of_residence, 
                      cdb_personal_customer.phone_ind, cdb_personal_customer.email_ind, cdb_personal_customer.prompt_ind, 
                      cdb_personal_customer.sms_ind, to_timestamp(cdb_personal_customer.all_prod_mail_updt, "yyyy-mm-dd") as 
                      all_prod_mail_updt, to_timestamp(cdb_personal_customer.phone_ind_updt, "yyyy-mm-dd") as phone_ind_updt, 
                      to_timestamp(cdb_personal_customer.email_ind_updt, "yyyy-mm-dd") as email_ind_updt, 
                      to_timestamp(cdb_personal_customer.prompt_ind_updt, "yyyy-mm-dd") as prompt_ind_updt, 
                      to_timestamp(cdb_personal_customer.sms_ind_updt, "yyyy-mm-dd") as sms_ind_updt, 
                      cdb_personal_customer.ctry_of_birth, cdb_personal_customer.place_of_birth, cdb_personal_customer.tax_number, 
                      cdb_personal_customer.crt_issuing_ctry, cdb_personal_customer.mobile_phone_no, 
                      cdb_personal_customer.email_address, cdb_personal_customer.pref_phone_no_ind, 
                      cdb_personal_customer.cust_progress_ind, cdb_personal_customer.last_cont_sat_rate, 
                      to_timestamp(cdb_personal_customer.last_cont_sat_date, "yyyy-mm-dd") as last_cont_sat_date, 
                      cdb_personal_customer.dpa_consent_marker, to_timestamp(cdb_personal_customer.home_phone_no_updt, "yyyy-mm-dd") as 
                      home_phone_no_updt, to_timestamp(cdb_personal_customer.bus_phone_no_updt, "yyyy-mm-dd") as bus_phone_no_updt, 
                      to_timestamp(cdb_personal_customer.mob_phone_no_updt, "yyyy-mm-dd") as mob_phone_no_updt, 
                      cdb_personal_customer.prev_home_phone_no, cdb_personal_customer.prev_bus_phone_no, 
                      cdb_personal_customer.prev_mob_phone_no, to_timestamp(cdb_personal_customer.chnge_dt_prev_home, "yyyy-mm-dd") as 
                      chnge_dt_prev_home, to_timestamp(cdb_personal_customer.chnge_dt_prev_bus, "yyyy-mm-dd") as chnge_dt_prev_bus, 
                      to_timestamp(cdb_personal_customer.chnge_dt_prev_mob, "yyyy-mm-dd") as chnge_dt_prev_mob, 
                      cdb_personal_customer.rt_ind, cdb_personal_customer.ctry_of_nationalty, cdb_personal_customer.channel_branch_ind, 
                      cdb_personal_customer.channel_inet_ind, cdb_personal_customer.channel_phone_ind, 
                      cdb_personal_customer.channel_atm_ind, cdb_personal_customer.contact_period_cd, 
                      cdb_personal_customer.passport_no, to_timestamp(cdb_personal_customer.passport_exp_date, "yyyy-mm-dd") as 
                      passport_exp_date, cdb_personal_customer.passport_ctry, cdb_customer_portfolio.portfolio_code, 
                      to_timestamp(cdb_customer_portfolio.portfolio_date, "yyyy-mm-dd") as portfolio_date, 
                      cdb_tcwdisc_disab_cust.disability_code, cdb_tcwdisc_disab_cust.disability_desc, tcwpex1.src_of_income , 
                      to_timestamp(cdb_portfolio_details.pfolio_as_of_date, "yyyy-mm-dd") as pfolio_as_of_date, cdb_portfolio_details.salary_ref_no, 
                      cdb_portfolio_details.rm_surname, cdb_portfolio_details.rm_forename, cdb_portfolio_details.job_descptn_code, 
                      cdb_tcwppsn_pps_num.customer_type, cdb_tcwppsn_pps_num.pps_tax_charity_no, 
                      cdb_tcwppsn_pps_num.verificatn_status, to_timestamp(cdb_tcwppsn_pps_num.pps_num_last_chng_date, "yyyy-mm-dd") as pps_num_last_change_date, 
                      cdb_tcwppsn_pps_num.update_count 
                      from 
                      cdb_personal_customer_tbl cdb_personal_customer left outer join 
                      cdb_customer_portfolio_tbl cdb_customer_portfolio on cdb_personal_customer.customer_id = 
                      cdb_customer_portfolio.customer_id and cdb_personal_customer.src_sys_id = cdb_customer_portfolio.src_sys_id 
                      and cdb_personal_customer.src_sys_inst_id = cdb_customer_portfolio.src_sys_inst_id left outer join 
                      tcwdisc_disab_cust_tbl cdb_tcwdisc_disab_cust on cdb_personal_customer.customer_id = 
                      cdb_tcwdisc_disab_cust.customer_id and cdb_personal_customer.src_sys_id = cdb_tcwdisc_disab_cust.src_sys_id 
                      and cdb_personal_customer.src_sys_inst_id = cdb_tcwdisc_disab_cust.src_sys_inst_id left outer join         
                      tcwscvw_scv_tbl tcwscvw_scv on cdb_personal_customer.customer_id = tcwscvw_scv.customer_id and 
                      cdb_personal_customer.src_sys_id = tcwscvw_scv.src_sys_id left outer join tcwpex1_pcus_ext1_tbl tcwpex1 on 
                      tcwpex1.customer_id = cdb_personal_customer.customer_id and tcwpex1.src_sys_id = 
                      cdb_personal_customer.src_sys_id and tcwpex1.src_sys_inst_id = cdb_personal_customer.src_sys_inst_id left 
                      outer join cdb_portfolio_details_tbl cdb_portfolio_details on cdb_customer_portfolio.portfolio_code = 
                      cdb_portfolio_details.portfolio_codeas and cdb_customer_portfolio.src_sys_id = cdb_portfolio_details.src_sys_id 
                      and cdb_customer_portfolio.src_sys_inst_id = cdb_portfolio_details.src_sys_inst_id left outer join 
                      tcwppsn_pps_num_tbl cdb_tcwppsn_pps_num on cdb_tcwppsn_pps_num.customer_id = 
                      cdb_personal_customer.customer_id and cdb_tcwppsn_pps_num.src_sys_id = cdb_personal_customer.src_sys_id and 
                      cdb_tcwppsn_pps_num.src_sys_inst_id = cdb_personal_customer.src_sys_inst_id""")

        individual_df = individual_df.na.fill('null')
        individual_df.show(truncate=False)
        individual_df = checkData(individual_df, cdb_customer_portfolio_df, cdb_tcwscvw_scv_df, cdb_tcwppsn_pps_num_df,
                                  cdb_tcwpex1_pcus_ext1_df, tcwdisc_disab_cust_df, cdb_portfolio_details_df,
                                  personal_customer_df)

        handle_status_flag(spark, individual_df)
        individual_df = individual_df.drop('record_status')

        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'success', 'file processed')
    except ParseException as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'SqlQueryParserError', str(ex))
    except QueryExecutionException as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))
    except AnalysisException as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'DataFrameError', str(ex))
    except KafkaError as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))
    except MongoException as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'MongoError', str(ex.getmessage()))
    except Py4JJavaError as ex:
        print(ex)
        writeApplicationStatusToFile(path_kafka_hdfs, 'GeneralError',str(ex.getmessage()))

##################################################### UTILITIES ##############################################################################################
def getUnion(spark,cdb_customer_portfolio_df,cdb_tcwscvw_scv_df,cdb_tcwppsn_pps_num_df,cdb_tcwpex1_pcus_ext1_df,tcwdisc_disab_cust_df,cdb_portfolio_details_df):

    cdb_customer_portfolio_df.createOrReplaceTempView("cdb_customer_portfolio_tbl")
    cdb_tcwscvw_scv_df.createOrReplaceTempView("tcwscvw_scv_tbl")
    cdb_tcwppsn_pps_num_df.createOrReplaceTempView("tcwppsn_pps_num_tbl")
    cdb_tcwpex1_pcus_ext1_df.createOrReplaceTempView("tcwpex1_pcus_ext1_tbl")
    tcwdisc_disab_cust_df.createOrReplaceTempView("tcwdisc_disab_cust_tbl")
    cdb_portfolio_details_df.createOrReplaceTempView("cdb_portfolio_details_tbl")
    custtemp_df = cdb_customer_portfolio_df.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                                   "src_extract_ts").union(
        cdb_tcwscvw_scv_df.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg", "src_extract_ts")) \
        .union(cdb_tcwppsn_pps_num_df.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                             "src_extract_ts")).union(
        cdb_tcwpex1_pcus_ext1_df.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                        "src_extract_ts")) \
        .union(tcwdisc_disab_cust_df.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                            "src_extract_ts"))
    # .union(cdb_portfolio_details_df.select("customer_id","src_sys_id","src_sys_inst_id","src_evt_typ_flg","src_extract_ts"))

    custtemp_df = custtemp_df.dropDuplicates()
    print('-------------custtemp_df--------1')
    print(str(custtemp_df.count()))
    custtemp_df.show()
    print('----------------------------------union----------------start')
    cust_df = custtemp_df.filter(custtemp_df['src_sys_id'] != '')
    cust_df.show()
    print('----------------------------------union----------------end')
    return cust_df


def checkData(dest_dff,cdb_customer_portfolio_df,cdb_tcwscvw_scv_df,cdb_tcwppsn_pps_num_df,cdb_tcwpex1_pcus_ext1_df,tcwdisc_disab_cust_df,cdb_portfolio_details_df,personal_customer_df):
    # personal_customer_df = personal_customer_df.filter(personal_customer_df.customer_id != 0)
    # if personal_customer_df.count()==0:
    dest_temp_df = removecolumn(dest_dff, personal_customer_df, 'personal_customer_df')
    # dest_temp_df = removecolumn(dest_temp_df,cdb_portfolio_details_df,'cdb_portfolio_details_df')
    dest_temp_df = removecolumn(dest_temp_df, tcwdisc_disab_cust_df, 'tcwdisc_disab_cust_df')
    dest_temp_df = removecolumn(dest_temp_df, cdb_tcwpex1_pcus_ext1_df, 'cdb_tcwpex1_pcus_ext1_df')
    dest_temp_df = removecolumn(dest_temp_df, cdb_tcwppsn_pps_num_df, 'cdb_tcwppsn_pps_num_df')
    dest_temp_df = removecolumn(dest_temp_df, cdb_tcwscvw_scv_df, 'cdb_tcwscvw_scv_df')
    dest_temp_df = removecolumn(dest_temp_df, cdb_customer_portfolio_df, 'cdb_customer_portfolio_df')

    return dest_temp_df

def removecolumn(dest_temp,source_df,dataframename):
    source_df = source_df.filter(source_df.customer_id != 0)
    if source_df.count()==0:
        for col_name in source_df.columns:
            if col_name!='customer_id' and col_name!='src_sys_inst_id' and col_name!='src_sys_id' and col_name!='record_status' and col_name!='src_evt_typ_flg' and col_name!='src_extract_ts':
                dest_temp = dest_temp.drop(col_name)

    return dest_temp

def getcombineall(spark, personal_customer_df, datapipelinetable):

    personalcustomer_dff=getCustomerDetails(spark, personal_customer_df, datapipelinetable)

    customer_df = personal_customer_df.filter(personal_customer_df.customer_id != 0)
    datapipelinetable_df = datapipelinetable.filter(datapipelinetable.src_sys_inst_id != '')

    if (customer_df.count() !=0 and datapipelinetable_df.count() == 0):
        personalcustomer_dff.createOrReplaceTempView("custone")
        customer_df.createOrReplaceTempView("custtwo")

        personalcustomer_dff=spark.sql(''' select b.record_status,a.* from custtwo a inner join custone b on a.customer_id = b.customer_id 
        and a.src_sys_id = b.src_sys_id and a.src_sys_inst_id = b.src_sys_inst_id  ''')

    else:
         personalcustomer_dff.createOrReplaceTempView("custone")
         customer_df = customer_df.withColumnRenamed("customer_id", "customer_id_temp")
         customer_df = customer_df.withColumnRenamed("src_sys_id", "src_sys_id_temp")
         customer_df = customer_df.withColumnRenamed("src_sys_inst_id", "src_sys_inst_id_temp")
         customer_df = customer_df.withColumnRenamed("src_evt_typ_flg", "src_evt_typ_flg_temp")
         customer_df = customer_df.withColumnRenamed("src_extract_ts", "src_extract_ts_temp")


         customer_df.createOrReplaceTempView("custtwo")

         personalcustomer_dff = spark.sql(''' select a.record_status,a.customer_id,a.src_sys_id,a.src_sys_inst_id,a.src_evt_typ_flg ,a.src_extract_ts,b.* 
         from custone a  left outer join custtwo b on a.customer_id = b.customer_id_temp 
           and a.src_sys_id = b.src_sys_id_temp and a.src_sys_inst_id = b.src_sys_inst_id_temp  ''')

    return personalcustomer_dff


def getCustomerDetails(spark, personal_customer_df, datapipelinetable_df):
    customer_df = personal_customer_df.filter(personal_customer_df.customer_id != 0)
    # datapipelinetable_df = datapipelinetable.filter(datapipelinetable.customer_id != 0)
    print('customer records::' + str(customer_df.count()))
    print('second table records::' + str(datapipelinetable_df.count()))

    if (datapipelinetable_df.count() > 0):
        personalcustomer_df = getNonExist_Records_in_PersonCustomer(spark, datapipelinetable_df, customer_df,
                                                                    mongo_driver_collection)
    else:
        personalcustomer_df = getCombinedExistNonExitCustomer(spark, customer_df, mongo_write_collection)
        personalcustomer_df = personalcustomer_df.filter(personalcustomer_df.record_status != 'yes')

    personalcustomer_df.show()
    return personalcustomer_df


def getCombinedExistNonExitCustomer(spark, perCustTable, mongo_collection):
    print('percusttable')
    perCustTable.show()
    pc_df_temp = getPersonCustomerRefData(spark, perCustTable, mongo_collection)
    print('--------------pc_df_temp---------------start')
    pc_df_temp.show(100)
    print('--------------pc_df_temp---------------end')
    print('----start---1')
    if pc_df_temp.count() > 0:
        print('----start---2')
        pc_df_temp = pc_df_temp.drop('_id')
        pc_df_temp = pc_df_temp.withColumn("record_status", lit('yes'))

        temp_percust = perCustTable.join(pc_df_temp, "customer_id", "left_anti")
        print('--------------temp_percust---------------start')
        temp_percust.show(100)
        print('--------------temp_percust---------------end')

        if temp_percust.count() > 0:
            print('----start---2')
            temp_percust = temp_percust.withColumn("record_status", lit('no'))
            temp_percust.createOrReplaceTempView("temp_percust")
            pc_df_temp.createOrReplaceTempView("pc_df_temp")
            perCustTable = spark.sql(""" select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id,src_evt_typ_flg,record_status from temp_percust
                                   union
                                   select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id,src_evt_typ_flg,record_status from pc_df_temp                    
                                   """)

        else:
            print('----start---3')
            perCustTable = pc_df_temp
    else:
        print('----start---4')
        tempcust_df = perCustTable.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                          "src_extract_ts")
        perCustTable = tempcust_df.withColumn("record_status", lit('no'))

    print('----start---5')
    perCustTable.show()
    return perCustTable


def getdiff_records(spark, df1, df2):
    df1.createOrReplaceTempView("temp1")
    print('-----------------df1----------------------')
    df1.show()

    print('-----------------df2----------------------')
    df2.show()

    df2.createOrReplaceTempView("temp2")
    temp = spark.sql(""" select temp1.customer_id,temp1.src_extract_ts,temp1.src_sys_id,temp1.src_sys_inst_id from temp1
                            inner join temp2 on 
                            temp1.customer_id = temp2.customer_id and 
                            temp1.src_sys_id = temp2.src_sys_id and 
                            temp1.src_sys_inst_id = temp2.src_sys_inst_id
                            """)

    return temp


def getPersonCustomerRefDataDriver(spark, refDataFrame, mongo_collection_read):
    cust_id = [int(i.customer_id) for i in refDataFrame.select('customer_id').collect()]
    pipeline = "[{ $project: {_id: 1, customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_extract_ts:1}},{'$match': {'customer_id':{$in: " + str(
        cust_id) + "}}}]"
    print(pipeline)
    reference_data_df = read_from_mongo(spark, mongo_collection_read, pipeline)
    return reference_data_df

def getDriverRefDatat(spark,temp_df,drive_mongo_collections):
    temp_dff = temp_df.dropDuplicates()
    cust_df = getPersonCustomerRefDataDriver(spark, temp_dff, drive_mongo_collections)
    print('----------------------------2')
    cust_df.show()

    print('cust_df.count()')
    print(str(cust_df.count()))

    if cust_df.count() != temp_df.count():
        print('----------------------------3')
        cust_temp_df = getPersonCustomerRefData(spark, temp_dff, mongo_write_collection)
        print('----------------------------4')
        cust_temp_df.show()
        cust_temp_df.createOrReplaceTempView("cust_temp_df")
        cust_df.createOrReplaceTempView("cust_df")
        if cust_temp_df.count() > 0 & cust_df.count() > 0:
            print('----------------------------4.4')
            cust_df = spark.sql(""" select * from cust_temp_df
                                   union
                                   select * from cust_df
                                   """)
        elif cust_temp_df.count() > 0:
            print('----------------------------4.6')
            cust_df = spark.sql(""" select * from cust_temp_df """)

    return cust_df


def getNonExist_Records_in_PersonCustomer(spark, checktable, percusttable, drive_mongo_collection):
    if (checktable.count()) > 0:
        temp_dff = checktable.filter(~checktable["customer_id"].isin(
            [int(i.customer_id) for i in percusttable.select("customer_id").collect()]))

        cust_exit_df = percusttable.join(temp_dff, "customer_id", "left_anti")
        print('----------temp_dff----')
        temp_dff.show()
        print('----------cust_exit_df----')
        cust_exit_df.show()

        if temp_dff.count() > 0:
            print('----------------------------1')
            personal_customer_df_temp=getDriverRefDatat(spark, temp_dff, mongo_write_collection)
            print('--------------personal_customer_df_temp----------------------start')
            personal_customer_df_temp.show()
            print('--------------personal_customer_df_temp----------------------end')
            print(str(personal_customer_df_temp.count()))
            print('--------------print(str(personal_customer_df_temp.count()))----------------------end')

            if personal_customer_df_temp.count() > 0:
                print('----------------------------5')
                personal_customer_df_temp = personal_customer_df_temp.drop('_id')
                personal_customer_df_temp = getdiff_records(spark, personal_customer_df_temp, temp_dff)
                print('----------------------------6')
                personal_customer_df_temp.show()
                print('----------------------------7')
                if cust_exit_df.count() > 0:
                    cust_exit_df.createOrReplaceTempView("custexit_df")
                    personal_customer_df_temp.createOrReplaceTempView("personal_customer_df_temp")
                    percusttable = spark.sql(""" select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id from custexit_df
                    union
                    select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id from personal_customer_df_temp                    
                    """)
                    percusttable = percusttable.withColumn("src_evt_typ_flg", lit("in"))
                else:
                    percusttable = personal_customer_df_temp.withColumn("src_evt_typ_flg", lit("in"))

            else:
                percusttable = cust_exit_df
        else:
            percusttable = cust_exit_df

    percusttable = getCombinedExistNonExitCustomer(spark, percusttable, mongo_write_collection)
    print('------------percusttable-------------')
    percusttable.show()
    return percusttable


def getPersonCustomerRefData(spark, refdataframe, mongo_collection_write):
    print(mongo_collection_write)
    pipeline = "[{ $project: {_id: 1, customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1,src_extract_ts:1}},{'$match': {'customer_id':{$in: " + str(
        [int(i.customer_id) for i in refdataframe.select('customer_id').collect()]) + "}}}]"
    print(pipeline)
    reference_data_df = read_from_mongo(spark, mongo_collection_write, pipeline)
    return reference_data_df

def getEmptyDataFrame(refDataFrame, filtertable):
    tempDF = refDataFrame.filter(
        refDataFrame['SRC_INGEST_MAP'] == filtertable)
    return tempDF

def handle_status_flag(spark, df):
    try:
        not_up_status_df = df.filter(((df['src_evt_typ_flg'] != "up") & (df['src_evt_typ_flg'] != "dl")))
        if not_up_status_df.count() > 0:
            in_yes_df = not_up_status_df.filter(((df['record_status'] == "yes")))
            if in_yes_df.count() > 0:
                in_yes_df = in_yes_df.drop('record_status')
                in_yes_df.createOrReplaceTempView("in_yes_df")
                pipeline = "[{ $project: {_id: 1, customer_id: 1,customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1}},{'$match': {'customer_id':{$in: " + str(
                    [int(i.customer_id) for i in in_yes_df.select('customer_id').collect()]) + "}}}]"
                # print(pipeline)
                reference_yes_df = read_from_mongo(spark, mongo_write_collection, pipeline)
                if reference_yes_df.count() > 0:
                    reference_yes_df.createOrReplaceTempView("reference_yes_df")
                    status_yes_df = spark.sql("""  select distinct b._id,a.* from in_yes_df a
                                                                                inner join reference_yes_df b on a.customer_id=b.customer_id
                                                                                and a.src_sys_id=b.src_sys_id and a.src_sys_inst_id=b.src_sys_inst_id
                                                                                """)

                    write_to_mongo(status_yes_df, mongo_write_collection)
            in_no_df = not_up_status_df.filter(((df['record_status'] == "no")))
            if in_no_df.count() > 0:
                in_no_df = in_no_df.drop('record_status')
                write_to_mongo(in_no_df, mongo_write_collection)


        up_status_df = df.filter(((df['src_evt_typ_flg'] == "up") | (df['src_evt_typ_flg'] == "dl")))
        up_status_df = up_status_df.drop('record_status')
        up_status_df.createOrReplaceTempView("up_status_data")
        if (up_status_df.count()) > 0:
            print(str(datetime.now().strftime(
                 '%Y-%m-%d %H:%M:%S')) + ":: processing started for records. writing logical source datasss in "
                                        "mongodb for src_evt_typ_flg up or dl status "
                                        "collection: " + mongo_write_collection)

            pipeline = "[{ $project: {_id: 1, customer_id: 1,customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1}},{'$match': {'customer_id':{$in: " + str(
                [int(i.customer_id) for i in up_status_df.select('customer_id').collect()]) + "}}}]"
            reference_data_df = read_from_mongo(spark, mongo_write_collection, pipeline)
            if reference_data_df.count()>0:
                reference_data_df.createOrReplaceTempView("reference_data")
                up_status_data_df = spark.sql("""  select distinct b._id,a.* from up_status_data a
                                                            inner join reference_data b on a.customer_id=b.customer_id
                                                            and a.src_sys_id=b.src_sys_id  and a.src_sys_inst_id=b.src_sys_inst_id
                                                            """)

                write_to_mongo(up_status_data_df, mongo_write_collection)
            else:
                up_status_df.show(1000)
                write_to_mongo(up_status_df, mongo_write_collection)
            print(str(datetime.now().strftime(
                 '%Y-%m-%d %H:%M:%S')) + ":: processing done for records. writing  logical source data in "
                                        "mongodb "
                                        "for src_evt_typ_flg up or dl status "
                                        "collection: " + mongo_write_collection)


    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())



def read_from_mongo(spark, collection, pipeline):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + ":: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', False) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ":: Written CDB  Logical Source "
                                                                  "Data in MongoDB collection: " + mongo_write_collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def getMongoDBConfiguration():
    try:
        config = configparser.ConfigParser()
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        raise ex

def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ods_ls_cdb_individual_asso_eod","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex

if __name__ == '__main__':
    main()
