
__author__ = "vermanx"
# Filename: electronic_address_main.py
# Mapping: m_CDB_LS_Party_Electronic_Address
# TRN_NME: LS_CDB_ELECTRONIC_ADDRESS
#
# Source/Target details:
# Input : STREAMING.CDB.TCWCUEA-CUS-E-ADDR.STD
# Output: Mongo Collection- LS_CDB_ELECTRONIC_ADDRESS; Kafka Topic- STREAMING.CDB.ELECTRONIC-ADDRESS.LDM

# Electronic Address
#######################################################################################################################
from pyspark.sql.utils import ParseException, QueryExecutionException, AnalysisException
from py4j.protocol import Py4JJavaError
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_json, struct, lit, col
from datetime import datetime
import sys
import os
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser



class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

# Variables populated at runtime
path_kafka_hdfs = sys.argv[1]
mongo_write_collection = sys.argv[2]
kafka_topic = sys.argv[3]
kafka_bootstrap_server = sys.argv[4]
kafka_source_topic_elec_addr = sys.argv[5]

#######################################################################################################################

def main():
    try:
        global debug, db_url, db_database
        debug=1
        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        # spark = SparkSession.builder.config("spark.sql.warehouse.dir", u'hdfs:///user/spark/warehouse').getOrCreate()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ' :: SPARK SESSION INITIALIZED. STARTING LS_CDB_ELECTRONIC_ADDRESS PIPELINE!!!! ')
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ' :: Reading records for LS_CDB_ELECTRONIC_ADDRESS pipeline from Kafka_HDFS ')

        try:
            record_from_kafka_hdfs = spark.read.json(path_kafka_hdfs)
            file_cnt = record_from_kafka_hdfs.count()
        except: file_cnt=0
        if file_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +" :: File not available or no records present")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +" :: Aborting the process")
            exit(0)
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +" :: Found records: "+str(file_cnt))
            if debug == 1: record_from_kafka_hdfs.show(5, truncate=False)

        ## Gathering the MongoDB information
        db_url, db_database = getMongoDBConfiguration()

        ############# Processing Electronic Address records #############
        print(str(datetime.now().strftime( '%Y-%m-%d %H:%M:%S')) + ' :: Fetching records from ' + kafka_source_topic_elec_addr)
        try:
            elec_addr_df = record_from_kafka_hdfs.select("CUSTOMER_ID","SRC_SYS_ID","SRC_SYS_INST_ID","SRC_EVT_TYP_FLG",
                                     "SRC_EXTRACT_TS","E_ADDR_TYPE","E_ADDR_PURPOSE","UPDATE_DATE_TIME","E_ADDR").\
                filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_elec_addr)
            e_addr_cnt = elec_addr_df.count()
        except: e_addr_cnt = 0;

        if e_addr_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Electronic_Address records aren't available")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, "FAILURE", "Electronic_Address records aren't available")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, "ABORT", "Aborting the LS process - Electronic_Address")
            exit(0)
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '"+str(e_addr_cnt)+"' "
                  +kafka_source_topic_elec_addr+" records")
            if debug == 1: elec_addr_df.show(5, truncate=False)

        for col in elec_addr_df.columns:
            elec_addr_df = elec_addr_df.withColumnRenamed(col, col.lower())

        elec_addr_df.createOrReplaceTempView("cdb_tcwcuea_cus_e_addr_tbl")

        electronic_address_df = spark.sql("""SELECT DISTINCT customer_id, src_sys_id, src_sys_inst_id, src_evt_typ_flg, 
                e_addr_type, e_addr_purpose, ltrim(rtrim(e_addr)) as e_addr, 
                to_timestamp(update_date_time, "yyyy-MM-dd't'HH:mm") as update_date_time, 
                to_timestamp(src_extract_ts, "yyyy-MM-dd't'HH:mm:ss") as src_extract_ts 
            from cdb_tcwcuea_cus_e_addr_tbl where customer_id is not NULL
            ORDER BY src_extract_ts
            """)

        electronic_address_df = electronic_address_df.na.fill("")
        if debug == 1 : electronic_address_df.show(5, truncate=False)

        if electronic_address_df.count() > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing the data for IN & UP/DL records")
            kafka_data = handle_status_flag(spark, electronic_address_df)
            if kafka_data.count() > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed processing IN & UP/DL records")
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing '0' IN & UP/DL records")
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
                writeApplicationStatusToFile(spark,path_kafka_hdfs, 'NO_RECORDS', "'0' records processed, Aborting the process.")


        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Creating Topic Name LS key for Kafka")
        electronic_address_df = kafka_data.withColumn("SRC_LS_MAP", lit(kafka_topic))
        electronic_address_df = electronic_address_df.withColumn("value", to_json(struct([electronic_address_df[x]
                                                                          for x in electronic_address_df.columns])))

        if debug == 1: electronic_address_df.show(5, truncate=False)
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Producing Electronic_Address data onto Kafka.")
        produce_on_kafka(electronic_address_df, kafka_topic)
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed successfully.")
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS', 'File Processed')
    except ParseException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryParserError', str(ex))

    except QueryExecutionException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))

    except AnalysisException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'DataFrameError', str(ex))

    except KafkaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))

    except MongoException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'MongoError', str(ex.getmessage()))

    except Py4JJavaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'GeneralError',
                                     ex.java_exception.toString())


# ##################################################### UTILITIES ##############################################################################################

## Processing INSERT or UPDATE/DELETE records
def processIN_UPDLRecords(spark, df, dmlStr):
    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing "+dmlStr+" records.")
    if debug == 1: df.show(5, truncate=False)

    pp_cols_df = df.select("customer_id", "src_sys_id", "src_sys_inst_id")
    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating pipeline for unmatched records")
    pipeline = "[{ $project: {_id: 1, customer_id:1, src_sys_id:1, src_sys_inst_id:1}}," \
               "{'$match': {'customer_id':{$in: " + str([int(i.customer_id) for i in df.select('customer_id').collect()]) + "}}}]"

    if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: pipeline:\n" + pipeline + "\n")
    try:
        pp_res_df = read_from_mongo_pipeline(spark, mongo_write_collection, pipeline)
        pp_res_cnt = pp_res_df.count()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Obtained '" + str(pp_res_cnt) + "' data from MongoDB pipeline")
        if debug == 1: pp_res_df.show(2, truncate=False)
    except: pp_res_cnt = 0

    if pp_res_cnt <= 0 and dmlStr == str('INSERT'):
        ## If MongoDB is empty, there will be 0 records returned/matched with pipeline
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There only New "+dmlStr+" records")
        final_df = df
        try:
            fin_cnt = final_df.count()
            if debug == 1: final_df.show(2, truncate=False)
        except: fin_cnt=0
    else:
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are matched "+dmlStr+" records at target")

        try:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" :: Processing "+dmlStr+" records to find driver match")
            if dmlStr == str('INSERT'):
                final_df = df.join(pp_res_df, on=['customer_id', 'src_sys_id', 'src_sys_inst_id'], how='left_outer')
            elif dmlStr != str('INSERT'):
                final_df = df.join(pp_res_df, on=['customer_id', 'src_sys_id', 'src_sys_inst_id'], how='left_outer')
                final_df=final_df.distinct()
            fin_cnt = final_df.count()
        except: fin_cnt=0

    if fin_cnt == 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There aren't any valid "+dmlStr+" records present")
    else:
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '"+str(fin_cnt)+"' "+dmlStr+" records")
        if debug == 1: final_df.show(5, truncate=False)
        try: id_cnt = final_df.select("_id").count()
        except: id_cnt = 0

        write_to_mongo(final_df, mongo_write_collection)
        if id_cnt > 0:  final_df = final_df.drop("_id")

        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS', 'Data written to MongoDB')

        return final_df

def handle_status_flag(spark, df):
    try:
        ##Handle INSERT records

        ##1. Write only NEW INSERT records to Mongo that doesn't have match at target
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Identiying IN records if available.")
        try:
            IN_df = df.filter(df['src_evt_typ_flg'] == "IN")
            IN_cnt=IN_df.count()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: IN Records count: " + str(IN_cnt))
            if debug == 1: IN_df.show(2, truncate=False)
        except: IN_cnt=0

        if IN_cnt <= 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: IN records aren't available.")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '"+str(IN_cnt)+"' IN records.")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing IN records.")
            Kafka_IN_df = processIN_UPDLRecords(spark, IN_df, "INSERT")
            print(str(datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')) + " :: Completed processing IN records.")
            if debug==1: Kafka_IN_df.show()

        ##2. Write UPDATE records to Mongo applying UPDATE process
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Initiating  UP/DL records.")
        UP_df = df.filter((df['src_evt_typ_flg'] == "UP") | (df['src_evt_typ_flg'] == "DL"))
        try:
            UP_cnt = UP_df.count()
        except: UP_cnt=0
        if UP_cnt<=0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are '"+str(UP_cnt)+"'  UP/DL records to process")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing UP/DL records.")
            Kafka_UPDL_df = processIN_UPDLRecords(spark, UP_df, "UP/DL")
            try: updl_cnt = Kafka_UPDL_df.count()
            except: updl_cnt=0
            if debug == 1: Kafka_UPDL_df.show()
            if updl_cnt > 0: Kafka_UPDL_df = Kafka_UPDL_df.drop("_id")
            # if debug == 1: Kafka_UPDL_df.show()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed UP/DL records.")

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Merging records on availability")
        if IN_cnt > 0 and UP_cnt > 0: kafka_df = Kafka_IN_df.union(Kafka_UPDL_df)
        elif IN_cnt > 0 and UP_cnt <= 0: kafka_df = Kafka_IN_df
        elif IN_cnt <= 0 and UP_cnt > 0: kafka_df = Kafka_UPDL_df
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found no valid IN or UP/DL records.")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'FAILURE', 'Found no valid IN or UP/DL records')
        return kafka_df

    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def read_from_mongo(spark, collection, pipeline):
    try:
        global db_url, db_database
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + ":: Loaded Source Collection: " + collection + " from MongoDB ")
        return df
    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def read_from_mongo_pipeline(spark, collection, pipeline):
    try:
        global db_url, db_database;
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        global db_url, db_database
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', True) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ":: Written CDB E-ADDRESS Logical Source "
                                                                  "Data in MongoDB collection: " + mongo_write_collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def produce_on_kafka(df, topic_name):
    try:
        df.selectExpr("CAST(value as STRING)"). \
            write. \
            format("kafka"). \
            option("kafka.bootstrap.servers", kafka_bootstrap_server). \
            option("topic", topic_name). \
            save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Produced records on Kafka Topic: " + kafka_topic)
    except Py4JJavaError as ex:
        raise KafkaError(ex.java_exception.toString())

def getMongoDBConfiguration():
    try:
        config = configparser.ConfigParser()
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        raise ex

def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ods_ls_cdb_electronic_address","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex


if __name__ == '__main__':
    main()
