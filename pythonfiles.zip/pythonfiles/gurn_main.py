__author__ = "xxsbb"
# Filename: gurn_main.py
# Mapping: m_CDB_LS_Party_Identification_GURN
# TRN_NME: LS_CDB_GURN
#
# Source/Target details:
# Input :STREAMING.CDB.PERSONAL-CUSTOMER.STD, STREAMING.CDB.TCWSCVW-SCV.STD
# Output: Mongo Collection- LS_CDB_GURN; Kafka Topic- STREAMING.CDB.GURN.LDM

# GURN

#######################################################################################################################
from pyspark.sql.functions import to_json, struct, concat, lit
import pyspark
from pyspark.sql.types import *

from py4j.protocol import Py4JJavaError
from pyspark.sql import SparkSession
import sys
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser

import  os
from datetime import datetime

from pyspark.sql.utils import QueryExecutionException
from pyspark.sql.utils import AnalysisException
from pyspark.sql.utils import ParseException

class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

## Variables populated at runtime
path_kafka_hdfs = sys.argv[1]
mongo_write_collection = sys.argv[2]
kafka_topic = sys.argv[3]
kafka_bootstrap_server = sys.argv[4]
kafka_source_topic_tcwscvw_scv = sys.argv[5]
kafka_source_topic_personal_customer = sys.argv[6]
mongo_driver_collection = sys.argv[7]
# mongo_driver_collection="LS_CDB_DRIVER_CUST_TEST"

# F:\Project\ODS_Mongo\KafkaData\ALL_CDB_KAFKA_DATA.json GURN_TEST TEST tstrapp0002819.server.rbsgrp.mde:9092 TCWSCVW_SCV PERSONAL_CUSTOMER LS_CDB_DRIVER_CUST_TEST
# path_kafka_hdfs="F:\Project\ODS_Mongo\KafkaData\ALL_CDB_KAFKA_DATA.json"
# mongo_write_collection="TEST"
# kafka_topic="TEST"
# kafka_bootstrap_server="tstrapp0002819.server.rbsgrp.mde:9092"
# kafka_source_topic_tcwscvw_scv="TCWSCVW_SCV"
# kafka_source_topic_personal_customer="PERSONAL_CUSTOMER"
# configFilePath = "D:\\Users\\dvbbf\\RBS_GIT\\dbConfiguration.ini"
#######################################################################################################################

def main():
    try:
        # global debug, db_url, db_database
        # 0 - disables show, 1 - enables show
        debug = 1
        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        sc = spark.sparkContext

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: SPARK SESSION INITIALIZED. STARTING LS_CDB_GURN PIPELINE!!!! ')
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Reading records for LS_CDB_GURN pipeline from Kafka_HDFS ')
        # print("path_kafka_hdfs: "+ path_kafka_hdfs)
        record_from_kafka_hdfs = spark.read.json(path_kafka_hdfs)
        if debug == 1:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Printing records obtained from Kafka_HDFS')
            if record_from_kafka_hdfs.count() <= 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no records available to process")
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
                exit(0)
            if debug == 1: record_from_kafka_hdfs.show(30)

            ############# Processing Personal_Customer records #############
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Fetching records from '+kafka_source_topic_personal_customer)
            try:
                personal_customer_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS"). \
                filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_personal_customer)
                tbl_1_cnt = personal_customer_df.count()
            except: tbl_1_cnt = 0

        if tbl_1_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Table_1 Records are not available")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, "FAILURE", "Primary table doesn't have any records")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Continuing the process to find match from Second table with Customer_driver")
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(tbl_1_cnt) + "' "+kafka_source_topic_personal_customer+" records")
            if debug == 1: personal_customer_df.show(5)
            for col in personal_customer_df.columns:
                personal_customer_df = personal_customer_df.withColumnRenamed(col, col.lower())

            personal_customer_df.createOrReplaceTempView("personal_customer_tbl")
        ############################################################################################

        ## Table_2 - GURN
        ############# Fetching GURN (tcwscvw_scv) records #############
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Validating Secondary table")
        try:
            tcwscvw_scv_df = record_from_kafka_hdfs.select("SOURCE_SYSTEM", "CUSTOMER_IDENT", "GURN", "BRAND_ID",
                   "CUSTOMER_TYPE", "SRC_SYS_ID", "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS"). \
                filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwscvw_scv)
            tbl_2_cnt = tcwscvw_scv_df.count()
        except AnalysisException as ex:
            print("Raised an exception due to unavailability of records from " + kafka_source_topic_tcwscvw_scv)
            tbl_2_cnt = 0

        if tbl_2_cnt <= 0:
            ## - Second table doesn't have records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Table_2 records are not available")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ZERO_RECORDS', 'No records from secondary source')
        else:
            ## - When Second table has records.
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(tbl_2_cnt) + "' TCWSCVW_SCV records from Kafka_HDFS")
            if debug == 1: tcwscvw_scv_df.show(truncate=False)
            for col in tcwscvw_scv_df.columns:
                tcwscvw_scv_df = tcwscvw_scv_df.withColumnRenamed(col, col.lower())

            tcwscvw_scv_df.createOrReplaceTempView("tcwscvw_scv_tbl")
        ######################################END OF GURN - fetching records######################################################

        ## Gathering the MongoDB information
        # db_url, db_database = getMongoDBConfiguration()

        ##Joining both the datasets to find match & un-match records
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Joining tables on availability")

        ## Capturing 1 & 2 Table records; and also Matched GURN records with driver
        if tbl_1_cnt > 0 and tbl_2_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching Table_1 records & Table_2 matched/valid records.")
            try:
                df_gurn_match = spark.sql("""SELECT DISTINCT pc.customer_id, pc.src_sys_id, 
                    coalesce(gr.src_sys_inst_id, 'grp') as src_sys_inst_id,
                    coalesce(gr.src_evt_typ_flg, pc.src_evt_typ_flg) as src_evt_typ_flg, 
                    coalesce(gr.src_extract_ts, pc.src_extract_ts) as src_extract_ts, 
                    gr.source_system, gr.gurn, gr.brand_id, gr.customer_type 
                    from personal_customer_tbl pc left outer join tcwscvw_scv_tbl gr
                        on concat('p','|',pc.customer_id) = concat(gr.customer_type,'|',trim ( gr.customer_ident)) 
                        and pc.src_sys_id=gr.src_sys_id
                    where pc.customer_id is not NULL""")
                gurn_match_cnt = df_gurn_match.count()
            except: gurn_match_cnt=0

            if gurn_match_cnt > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found valid/match records from table 1 & 2")
            df_all_gurn=df_gurn_match
            if debug == 1: df_gurn_match.show(5, truncate=False)
            ######################################END OF Matching records######################################################

            ## Un-Matched GURN records
            ## Joining both to find un-matched GURN records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching unmatched records from Table_2, if any.")
            df_gurn_match.createOrReplaceTempView("pers_cust_match_tbl")
            try:
                df_gurn_unmatch = spark.sql("""SELECT DISTINCT gr.customer_ident, gr.src_sys_id, gr.src_sys_inst_id, 
                    gr.src_evt_typ_flg, gr.src_extract_ts, gr.source_system, gr.gurn, gr.brand_id, gr.customer_type 
                from tcwscvw_scv_tbl gr 
                where not exists (select pc.customer_id, pc.src_sys_id from pers_cust_match_tbl pc 
                    where concat('p','|',pc.customer_id) = concat(gr.customer_type,'|',trim ( gr.customer_ident)) 
                    and gr.src_sys_id = pc.src_sys_id) and gr.customer_ident is not null
                """)
                unmatch_cnt = df_gurn_unmatch.count()
            except: unmatch_cnt = 0
            if unmatch_cnt <= 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no unmatched records.")
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are "+str(unmatch_cnt)+" unmatched records.")
                if debug == 1: df_gurn_unmatch.show(5, truncate=False)

                ## Processing unmatched records against driver collection
                df_match_2 = process_UnMatchRecords(spark, df_gurn_unmatch)
                try: mtCnt_1 = df_match_2.count()
                except: mtCnt_1 = 0

                if mtCnt_1 == 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No Driver match records found")
                else:
                    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found match records from driver collection")
                    if debug == 1:
                        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Table_1 & Table_2 matched records")
                        df_gurn_match.show()
                        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Driver matched Table_2 records")
                        df_match_2.show()

                    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Combining the Customer Matched & Driver matched records.")
                    df_all_gurn = df_gurn_match.union(df_match_2)
                    if debug == 1: df_all_gurn.show(5, truncate=False)

                    df_gurn_match.createOrReplaceTempView("gurn_match_tbl")
                    df_match_2.createOrReplaceTempView("gurn_match_2_tbl")
                    # Results: df_all_gurn
            ######################################END OF Un-Matching records######################################################

        ## Table_1 records only
        elif tbl_1_cnt > 0 and tbl_2_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Records available only from Table_1")
            df_all_gurn = personal_customer_df

        ## Table_2 records only
        elif tbl_1_cnt <= 0 and tbl_2_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Records available only from Table_2, trying to match with Driver customer data")
            if debug == 1: tcwscvw_scv_df.show(5, truncate=False)

            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are " + str(tbl_2_cnt) + " unmatched records.")

            ## Checking Unmatched Table_2 records with Driver_table
            df_all_gurn = process_UnMatchRecords(spark, tcwscvw_scv_df)
            try: mtCnt_2 = df_all_gurn.count()
            except: mtCnt_2 = 0
            if mtCnt_2 == 0: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No match found at Driver customer.")
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found Table_2 match records with Driver collection")
                if debug == 1: df_all_gurn.show(5, truncate=False)
            # Results: df_all_gurn

        ## When both Tables have no data, we are aborting the application
        elif tbl_1_cnt <= 0 and tbl_2_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no valid records available to process.")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting.")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ABORT', 'Found 0 valid records, Aborting process.')
            exit(0)

        try: df_all_gurn_cnt = df_all_gurn.count()
        except: df_all_gurn_cnt=0
        if df_all_gurn_cnt <= 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no valid records to process.")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting.")
            exit(0)

        gurn_df = df_all_gurn.na.fill("")
        if debug == 1: gurn_df.show(5, truncate=False)
        try: gurn_cnt = gurn_df.count()
        except: gurn_cnt = 0

        if gurn_cnt > 0:
            ################## Processing data to identify IN & UP/DL accordingly ##################
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing data for IN/UP/DL records")

            ## Processing IN records for Mongo-Write and returns final records for Kafka-Write
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " Starting IN record processing")
            insert_df = handle_insert_flag(spark, gurn_df)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " Completed IN record processing")
            try:
                insert_cnt = insert_df.count()
                if debug == 1: insert_df.show(5, truncate=False)
            except: insert_cnt = 0

            ## Processing IN, UP/DL records for Mongo-Write and returns final records for Kafka-Write
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " Starting UP/DL record processing")
            update_df = handle_update_flag(spark, gurn_df)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " Completed UP/DL record processing")
            try:
                update_cnt = update_df.count()
                if debug == 1: update_df.show(5, truncate=False)
            except: update_cnt = 0

            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " Combining processed IN & UP/DL data on availability")
            if insert_cnt > 0 and update_cnt > 0: final_df = insert_df.union(update_df)
            elif insert_cnt > 0 and update_cnt == 0: final_df = insert_df
            elif insert_cnt == 0 and update_cnt > 0: final_df = update_df
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processed and received 0 records")
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed LS_GURN successfully")
                writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS',
                                             'No valid Inserts or match up/DL records. Completed successfully.')
                exit(0)

            # Final data for Kafka
            if debug == 1:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Final kafka IN & UP/DL data")
                final_df.show(5, truncate=False)

            ## Adding LS_Key Column to data
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Creating Topic Name LS key for Kafka")
            final_df = final_df.withColumn("SRC_LS_MAP", lit(kafka_topic))
            final_df = final_df.withColumn("value", to_json(struct([final_df[x] for x in final_df.columns])))

            ## Writing final LS data to Kafka
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing final data for Kafka: "+kafka_topic)
            if debug == 1: final_df.show(5, truncate=False)
            produce_on_kafka(final_df, kafka_topic)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: LS_GURN data written to Kafka successfully")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed LS_GURN successfully")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SUCCESS', 'Completed successfully')
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no records generated")
    except ParseException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'SqlQueryParserError', str(ex))
    except QueryExecutionException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))
    except AnalysisException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'DataFrameError', str(ex))
    except KafkaError as ex:
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))
    except MongoException as ex:
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'MongoError', str(ex.getmessage()))
    except Py4JJavaError as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'GeneralError',
                                     ex.java_exception.toString())


# ##################################################### UTILITIES ##############################################################################################

def process_UnMatchRecords(spark, df):
    try:
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating pipeline for unmatched records")
        pipeline = "[{ $project: {_id: 0, customer_id: 1, src_sys_id: 1}},{'$match': {'customer_id':{$in: " + str(
            [int(i.customer_ident) for i in df.select('customer_ident').collect()]) + "}}}]"

        if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: pipeline:\n"+pipeline+"\n")

        # mongo_driver_collection
        ## Fetching existing records from Collection for performing UP/DL over it.
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Finding match records from Collection- "+mongo_driver_collection)
        try:
            unMatch_ref_df = read_from_mongo_pipeline(spark, mongo_driver_collection, pipeline)
            if debug == 1:  unMatch_ref_df.show()

            df = df.withColumnRenamed("customer_ident", "customer_id")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Joining the results with primary data.")
            df_out = unMatch_ref_df.join(df, on=['customer_id','src_sys_id'], how='inner')
            if debug == 1: df_out.show(5, truncate=False)
        except:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No match record found from Driver-Collection.")
        return df_out
    except:
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No Match through pipeline over Driver-collection.")

def processStageMatchedRecords(spark, batch_IN_rec_df, stage_df):
    try:
        if debug == 1:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Batch IN records")
            batch_IN_rec_df.show()
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Stage records")
            stage_df.show()

        batch_IN_rec_df.createOrReplaceTempView("batch_cust_tbl")
        stage_df.createOrReplaceTempView("gurn_stage_tbl")

        ##Capture records un-changed
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Checking batch data for New IN records")

        ## Checking repeated IN records for Changes
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Checking for un/changed IN records")
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Identifying records that came again for finding changes")
        ## IN records that came again
        try:
            if debug == 1:
                print("Sampling Batch IN & Stage IN data")
                batch_IN_rec_df.show()
                stage_df.show()

            second_IN_data_df = spark.sql("""SELECT DISTINCT st._id, bt.customer_id, bt.src_sys_id, bt.src_sys_inst_id, 
                bt.src_evt_typ_flg, bt.src_extract_ts, coalesce(bt.source_system, st.source_system) as source_system, 
                coalesce(bt.gurn, st.gurn) as gurn, coalesce(bt.brand_id, st.brand_id) as brand_id, 
                coalesce(bt.customer_type, st.customer_type) as customer_type 
                from batch_cust_tbl bt 
                left outer join gurn_stage_tbl st 
                on bt.customer_id = st.customer_id and bt.src_sys_id = st.src_sys_id""")
            second_data_df_cnt = second_IN_data_df.count()
            if debug == 1: second_IN_data_df.show(5, truncate=False)
        except: second_data_df_cnt = 0
        # second_data_df_cnt

        if second_data_df_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing IN records received again to MongoDB - " + mongo_write_collection)
            write_to_mongo(second_IN_data_df, mongo_write_collection)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed writing records to MongoDB. \n")

            ##Capture only New records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Checking if there are any new IN records")
            try:
                batch_New_In_df = batch_IN_rec_df.join(stage_df, on=['customer_id', 'src_sys_id'], how='left_anti')
                batch_new_cnt = batch_New_In_df.count()
            except: batch_new_cnt = 0

            if batch_new_cnt > 0:
                if debug == 1: batch_New_In_df.show()
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing " + str(
                    batch_new_cnt) + " new IN records to MongoDB - " + mongo_write_collection)
                write_to_mongo(batch_New_In_df, mongo_write_collection)
                print(str(
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed writing IN records to MongoDB. \n")
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no New IN records. \n")

        ## Combining new & repeated data on availability
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating the complete valid batch IN records")
        if batch_new_cnt > 0 and second_data_df_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Combining IN Records which have New & repeated ones")

            bat_In = batch_New_In_df.select("customer_id","src_sys_id","src_sys_inst_id","src_evt_typ_flg",
                                "src_extract_ts","source_system","gurn","brand_id","customer_type")
            bat_In_2 = second_IN_data_df.select("customer_id","src_sys_id","src_sys_inst_id","src_evt_typ_flg",
                                "src_extract_ts","source_system","gurn","brand_id","customer_type")

            if debug == 1: bat_In.show(5, truncate=False); bat_In_2.show(5, truncate=False)
            batch_in_data = bat_In.union(bat_In_2)
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed combining New & repeated IN Records.")
            if debug == 1: batch_in_data.show()
            return batch_in_data

        elif batch_new_cnt > 0 and second_data_df_cnt == 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: All records are new records from batch")
            if debug == 1: batch_New_In_df.show(5, truncate=False)
            return batch_New_In_df

        elif batch_new_cnt == 0 and second_data_df_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: All records are ones that came again")
            if debug == 1 : second_IN_data_df.show(5, truncate=False)
            return second_IN_data_df

    except: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No Collection Match found for Batch IN data")

def handle_insert_flag(spark, df):
   try:
        global debug
        ins_cnt = up_rec_cnt = ref_cnt = in_batch_data_cnt = 0

        ############################ Handling only Insert records ############################
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing INSERT records")
        ins_status_df = df.filter(df['src_evt_typ_flg'] == "IN")
        try: ins_cnt = ins_status_df.count()
        except: ins_cnt = 0

        if ins_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(ins_cnt) + "' IN records.")
            if debug == 0: ins_status_df.show()
            ## Insert records would ideally come only once, however
            ## Fetching records from GURN_Table, to find if data already exists

            ## Get only matching IN Records from GURN_Collection and check if there is any update/change in data.
            print(str(datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')) + " :: Creating pipeline to get Collection match on IN records:\n")
            pipeline_in = "[{ $project: {_id: 1, customer_id:1, src_sys_id:1, src_sys_inst_id:1, src_evt_typ_flg:1, " \
                          "src_extract_ts:1, source_system:1, gurn:1, brand_id:1, customer_type:1" \
                          "}}," \
                          "{'$match': {'customer_id':{$in: " + \
                          str([int(i.customer_id) for i in ins_status_df.select('customer_id').collect()]) + "}}}]"
            if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Pipeline: " + pipeline_in)

            ## Fetching existing records from Collection for performing UP/DL over it.
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching IN-matched records from " + mongo_write_collection)
            try:
                df_gurn_stage = read_from_mongo_pipeline(spark, mongo_write_collection, pipeline_in)
                df_gurn_stage_cnt = df_gurn_stage.count()
                if df_gurn_stage_cnt > 0:
                    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Obtained " + str(
                        df_gurn_stage_cnt) + " collection matched IN records")
                    # (yet to check data changed or not)
                    if debug == 1: df_gurn_stage.show(5, truncate=False)
                else:
                    df_gurn_stage_cnt = 0
                    print(str(datetime.now().strftime(
                        '%Y-%m-%d %H:%M:%S')) + " :: No IN - matched records found at -" + mongo_write_collection)
            except: df_gurn_stage_cnt = 0

            ## If all IN records are new records and has no match with main collection, can be written.
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Checking if all the IN records are new records")
            if df_gurn_stage_cnt == 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: All available IN records are new records")
                ins_status_df.createOrReplaceTempView("pers_cust_tbl")
                new_IN_data = spark.sql("""SELECT DISTINCT pc.customer_id, pc.src_sys_id, pc.src_sys_inst_id, pc.src_evt_typ_flg, 
                        pc.src_extract_ts, coalesce(pc.source_system,'') as source_system, coalesce(pc.gurn,'') as gurn, 
                        coalesce(pc.brand_id,'') as brand_id, coalesce(pc.customer_type,'') as customer_type 
                        from pers_cust_tbl pc order by pc.src_extract_ts""")
                in_batch_data_cnt = new_IN_data.count()
                if debug == 1: new_IN_data.show(5, truncate=False)
                print(str(datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S')) + " :: Writing new IN records to MongoDB - " + mongo_write_collection)
                write_to_mongo(new_IN_data, mongo_write_collection)
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed writing IN records to MongoDB. \n")
                return new_IN_data

            elif df_gurn_stage_cnt > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Not all IN records are new, processing further.")

                ## processing to find IN Matched and Unmatched with Stage (GURN) data
                batch_in_rec_df = processStageMatchedRecords(spark, ins_status_df, df_gurn_stage)
                try: in_batch_data_cnt = batch_in_rec_df.count()
                except: in_batch_data_cnt = 0

                if in_batch_data_cnt > 0:
                    if debug == 1: batch_in_rec_df.show()
                    print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed writing IN records to MongoDB. \n")
                    batch_in_rec_df = batch_in_rec_df.drop("_id")
                    return batch_in_rec_df
        else:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found 0 INSERT records.")

   except Py4JJavaError as ex:
       raise MongoException(ex.java_exception.toString())
    ############################ End of INSERT records ############################

def handle_update_flag(spark, df):
    try:
        global debug
        ins_cnt = up_rec_cnt = ref_cnt = in_batch_data_cnt = 0

        ############################ Handling only UP/DL records ############################
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing UP/DL records")
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Checking for existence of UP/DL records")

        up_status_df = df.filter(((df['src_evt_typ_flg'] == "UP") | (df['src_evt_typ_flg'] == "DL")))
        try: up_rec_cnt = up_status_df.count()
        except: up_rec_cnt = 0

        ## Where there are no UP/DL records.
        if up_rec_cnt <= 0:print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found 0 UP/DL matching record")

        ## When there are UP/DL records.
        elif up_rec_cnt > 0:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(up_rec_cnt) + "' UP/DL records")
            if debug == 1: up_status_df.show(5, truncate=False)

            up_status_df.createOrReplaceTempView("update_status_tbl")

            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processing '" + str(up_rec_cnt) + "' UP/DL records.")
            pipeline = "[{ $project: {_id: 1, customer_id: 1, src_sys_id: 1, src_sys_inst_id: 1}},{'$match': {'customer_id':{$in: " + str(
                [int(i.customer_id) for i in up_status_df.select('customer_id').collect()]) + "}}}]"
            if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Pipeline: " + pipeline)

            ## Fetching existing records from Collection for performing UP/DL over it.
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Fetching records from Collection for performing UP/DL.")
            try:
                reference_data_df = read_from_mongo_pipeline(spark, mongo_write_collection, pipeline)
                ref_cnt = reference_data_df.count()
                if debug == 0:
                    print(str(datetime.now().strftime(
                        '%Y-%m-%d %H:%M:%S')) + " :: Sample data from UP/DL-matched_data & REF_Data.")
                    up_status_df.show(5, truncate=False)
                    reference_data_df.show(5, truncate=False)
            except: ref_cnt = 0

            if ref_cnt > 0:  ## When GURN has matching data with UP/DL records
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(
                    ref_cnt) + "' ref records from Collection.")
                reference_data_df.createOrReplaceTempView("reference_data")
                up_status_data_df = spark.sql("""SELECT DISTINCT b._id, a.* from update_status_tbl a 
                            left outer join reference_data b on a.customer_id=b.customer_id and a.src_sys_id = b.src_sys_id 
                            order by a.src_extract_ts asc""")
            else:  ## When GURN has no matching data with UP/DL records
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found no ref records from Collection.")
                up_status_data_df = spark.sql("""SELECT DISTINCT * FROM update_status_tbl ORDER BY src_extract_ts ASC""")
            try: up_dl_cnt = up_status_data_df.count()
            except: up_dl_cnt = 0

            if up_dl_cnt > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing UP/DL records to MongoDB - " + mongo_write_collection)
                if debug == 1: up_status_data_df.show()
                write_to_mongo(up_status_data_df, mongo_write_collection)
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Processed UP/DL records to MongoDB")

                ## Excluding _id column from dataframe
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Preparing UP/DL data for Kafka")
                up_dl_stats_df = up_status_data_df.drop("_id")
                if debug == 1: up_dl_stats_df.show(5, truncate=False)
                return up_dl_stats_df

    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())
def read_from_mongo(spark, collection):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .load()
        print(collection + " from MongoDB loaded to SPARK!")
        return df
    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def read_from_mongo_pipeline(spark, collection, pipeline):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        # db_url, db_database = getMongoDBConfiguration()
        db_url, db_database = getMongoDBConfiguration()
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', False) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Written CDB GURN Logical Source "
                                                                  "Data in MongoDB collection: " + mongo_write_collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def produce_on_kafka(df, topic_name):
    try:
        df.selectExpr("CAST(value as STRING)"). \
            write. \
            format("kafka"). \
            option("kafka.bootstrap.servers", kafka_bootstrap_server). \
            option("topic", topic_name). \
            save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Produced records on Kafka Topic: " + kafka_topic)
    except Py4JJavaError as ex:
        raise KafkaError(ex.java_exception.toString())

def getMongoDBConfiguration():
    try:
        config = configparser.ConfigParser()
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        raise ex

def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ods_ls_cdb_gurn","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex


if __name__ == '__main__':
    main()