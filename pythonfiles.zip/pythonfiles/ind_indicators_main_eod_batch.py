__author__ = "vermanx"
# Filename: ind_indicators_main.py
# Mapping: m_CDB_LS_Party_Indicators
# TRN_NME: LS_CDB_IND_INDICATORS
#
# Source/Target details:
# Input : STREAMING.CDB.TCWCIND-CUST-IND.STD, STREAMING.CDB.PERSONAL-CUSTOMER.STD
# Output: Mongo Collection- LS_CDB_IND_INDICATORS; Kafka Topic- STREAMING.CDB.IND-INDICATORS.LDM

# IND_INDICATORS
#######################################################################################################################
from pyspark.sql.functions import to_json, struct, concat, lit
import pyspark
from pyspark.sql.types import *
from py4j.protocol import Py4JJavaError
from pyspark.sql import SparkSession
import sys
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser

import  os
from datetime import datetime

from pyspark.sql.utils import QueryExecutionException
from pyspark.sql.utils import AnalysisException
from pyspark.sql.utils import ParseException

class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message


class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message


# Variables populated at runtime

path_kafka_hdfs = sys.argv[1]
mongo_write_collection = sys.argv[2]
kafka_bootstrap_server = sys.argv[3]
kafka_source_topic_tcwcind_cust_ind = sys.argv[4]
kafka_source_topic_personal_customer = sys.argv[5]
mongo_driver_collection = sys.argv[6]
columndata = sys.argv[7]
#######################################################################################################################


def main():
    try:
        global debug
        # 0 - disables show, 1 - enables show
        debug = 0
        print('file location::' + path_kafka_hdfs)

        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        # spark = SparkSession.builder.config("spark.sql.warehouse.dir", u'hdfs:///user/spark/warehouse').getOrCreate()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: SPARK SESSION INITIALIZED. STARTING '
                                                                  'LS_CDB_IND_INDICATORS PIPELINE!!!! ')
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Reading records for LS_CDB_IND_INDICATORS '
                                                                  'pipeline from Kafka_HDFS ')

        try:
            columndata_df = spark.read.json(columndata)
        except Py4JJavaError as ex:
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'GeneralError',
                                         ex.java_exception.toString())
            exit(0)

        # print("path_kafka_hdfs: "+ path_kafka_hdfs)
        record_from_kafka_hdfs = spark.read.json(
            path_kafka_hdfs)

        if debug == 1:
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ':: Printing records obtained from Kafka_HDFS')
            if record_from_kafka_hdfs.count() <= 0:
                print(str(
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are no records available to process")
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Aborting the process")
                exit(0)
            if debug == 1: record_from_kafka_hdfs.show(300)
        try:
            ############# Processing Personal_Customer records #############
            if debug == 1: print(str(datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')) + ':: Fetching records from ' + kafka_source_topic_personal_customer)

            personal_customer_df = record_from_kafka_hdfs.select("CUSTOMER_ID", "SRC_SYS_INST_ID", "SRC_SYS_ID",
                                                                     "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS").filter(
                record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_personal_customer)
            # personal_customer_df.show(truncate=False)
        except AnalysisException as ex:
            personal_customer_df = getEmptyDataFrame(columndata_df, kafka_source_topic_personal_customer).select("CUSTOMER_ID", "SRC_SYS_INST_ID", "SRC_SYS_ID",
                                                                     "SRC_EVT_TYP_FLG", "SRC_EXTRACT_TS")

            if personal_customer_df.count() <= 1:
                if debug == 1: print(
                            str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Table_1 Records are not available")
                writeApplicationStatusToFile(path_kafka_hdfs, "FAILURE", "Primary table doesn't have any records")
                if debug == 1: print(str(datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S')) + " :: Continuing the process to find match from Second table with Customer_driver")
            else:
                if debug == 1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(
                    personal_customer_df.count()) + "' " + kafka_source_topic_personal_customer + " records")
                if debug == 1: personal_customer_df.show(5)

            ############################################################################################

        try:
            ## Extract  data
            ############# Processing  records #############
            print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + " :: Validating " + kafka_source_topic_tcwcind_cust_ind + " table")

            cdb_tcwcind_cust_ind = record_from_kafka_hdfs.select("CUSTOMER_ID", "INDICATOR_TYPE", "INDICATOR_VALUE",
                                                         "CUSTOMER_TYPE", "UPDATE_DATE_TIME", "SRC_SYS_ID",
                                                         "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                         "SRC_EXTRACT_TS").filter(
                record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_tcwcind_cust_ind)
            # cdb_tcwcind_cust_ind.show(truncate=False)

        except AnalysisException as ex:
            cdb_tcwcind_cust_ind = getEmptyDataFrame(columndata_df, kafka_source_topic_tcwcind_cust_ind).select("CUSTOMER_ID", "INDICATOR_TYPE", "INDICATOR_VALUE",
                                                         "CUSTOMER_TYPE", "UPDATE_DATE_TIME", "SRC_SYS_ID",
                                                         "SRC_SYS_INST_ID", "SRC_EVT_TYP_FLG",
                                                         "SRC_EXTRACT_TS")

        if cdb_tcwcind_cust_ind.count() <= 1:
            ## - Second table doesn't have records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Table_2 records are not available")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'ZERO_RECORDS', 'No records from secondary source')
        else:
            ## - When Second table has records.
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(
                cdb_tcwcind_cust_ind.count()) +" records from Kafka_HDFS")
            if debug == 1: cdb_tcwcind_cust_ind.show(truncate=False)

        ######################################END OF tax - fetching records######################################################

        for col in cdb_tcwcind_cust_ind.columns:
            cdb_tcwcind_cust_ind = cdb_tcwcind_cust_ind.withColumnRenamed(col, col.lower())

        for col in personal_customer_df.columns:
            personal_customer_df = personal_customer_df.withColumnRenamed(col, col.lower())

        # Process the data for primary ,secondary table for update,insert, existance and driver table
        personal_customer_df=personal_customer_df.dropDuplicates()
        cdb_tcwcind_cust_ind = cdb_tcwcind_cust_ind.dropDuplicates()
        personalCustomer_df = getCustomerDetails(spark,  personal_customer_df, cdb_tcwcind_cust_ind)
        if personalCustomer_df.count() == 0:
            exit(0)

        personalCustomer_df = personalCustomer_df.dropDuplicates()

        cdb_tcwcind_cust_ind.createOrReplaceTempView("cdb_tcwcind_cust_ind_tbl")
        personalCustomer_df.createOrReplaceTempView("cdb_personal_customer_tbl")

        party_indicators_df = spark.sql("""SELECT cdb_personal_customer_tbl.record_status,cdb_personal_customer_tbl.src_sys_id, 
                            cdb_personal_customer_tbl.src_sys_inst_id, coalesce(cdb_tcwcind_cust_ind_tbl.src_evt_typ_flg, cdb_personal_customer_tbl.src_evt_typ_flg) as src_evt_typ_flg,
                            to_timestamp(coalesce(cdb_tcwcind_cust_ind_tbl.src_extract_ts, cdb_personal_customer_tbl.src_extract_ts), "yyyy-mm-dd't'hh:mm:ss") as src_extract_ts,
                            cdb_personal_customer_tbl.customer_id, 
                            cdb_tcwcind_cust_ind_tbl.indicator_type, cdb_tcwcind_cust_ind_tbl.indicator_value, 
                            cdb_tcwcind_cust_ind_tbl.customer_type, to_timestamp(cdb_tcwcind_cust_ind_tbl.update_date_time, "yyyy-mm-dd't'hh:mm:ss") as 
                            update_date_time from cdb_personal_customer_tbl
                            left outer join cdb_tcwcind_cust_ind_tbl on 
                            cdb_personal_customer_tbl.customer_id = cdb_tcwcind_cust_ind_tbl.customer_id and 
                            cdb_personal_customer_tbl.src_sys_id = cdb_tcwcind_cust_ind_tbl.src_sys_id and 
                            cdb_personal_customer_tbl.src_sys_inst_id = cdb_tcwcind_cust_ind_tbl.src_sys_inst_id
                            """)


        party_indicators_df = party_indicators_df.na.fill("")
        handle_status_flag(spark, party_indicators_df)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'SUCCESS', 'File Processed')
    except ParseException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'SqlQueryParserError', str(ex))
    except QueryExecutionException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))
    except AnalysisException as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'DataFrameError', str(ex))
    except KafkaError as ex:
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))
    except MongoException as ex:
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'MongoError', str(ex.getmessage()))
    except Py4JJavaError as ex:
        print(ex)
        writeApplicationStatusToFile(spark, path_kafka_hdfs, 'GeneralError',
                                     ex.java_exception.toString())

# ##################################################### UTILITIES ##############################################################################################

def getCustomerDetails(spark, personal_customer_df, datapipelinetable):
    customer_df = personal_customer_df.filter(personal_customer_df.customer_id != 0)
    datapipelinetable_df = datapipelinetable.filter(datapipelinetable.customer_id != 0)
    print('customer records::' + str(customer_df.count()))
    print('second table records::' + str(datapipelinetable_df.count()))

    if (datapipelinetable_df.count() > 0):
        personalcustomer_df = getNonExist_Records_in_PersonCustomer(spark, datapipelinetable_df, customer_df,
                                                                    mongo_driver_collection)
    else:
        personalcustomer_df = getCombinedExistNonExitCustomer(spark, customer_df, mongo_write_collection)
        personalcustomer_df = personalcustomer_df.filter(personalcustomer_df.record_status != 'yes')

    personalcustomer_df.show()
    return personalcustomer_df


def getCombinedExistNonExitCustomer(spark, percusttable, mongo_collection):
    pc_df_temp = getPersonCustomerRefData(spark, percusttable, mongo_collection)
    if pc_df_temp.count() > 0:
        pc_df_temp = pc_df_temp.drop('_id')
        pc_df_temp = pc_df_temp.withColumn("record_status", lit('yes'))
        temp_percust = percusttable.join(pc_df_temp, "customer_id", "left_anti")
        if temp_percust.count() > 0:
            temp_percust = temp_percust.withColumn("record_status", lit('no'))
            temp_percust.createOrReplaceTempView("temp_percust")
            pc_df_temp.createOrReplaceTempView("pc_df_temp")
            percusttable = spark.sql(""" select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id,src_evt_typ_flg,record_status from temp_percust
                                   union
                                   select customer_id,src_extract_ts,src_sys_id,src_sys_inst_id,src_evt_typ_flg,record_status from pc_df_temp                    
                                   """)

        else:
            percusttable = pc_df_temp
    else:

        tempcust_df = percusttable.select("customer_id", "src_sys_id", "src_sys_inst_id", "src_evt_typ_flg",
                                          "src_extract_ts")
        percusttable = tempcust_df.withColumn("record_status", lit('no'))

    percusttable.show()
    return percusttable


def getdiff_records(spark, df1, df2):
    df1.createOrReplaceTempView("temp1")
    df2.createOrReplaceTempView("temp2")
    temp = spark.sql(""" SELECT temp1.customer_id,temp1.src_extract_ts,temp1.src_sys_id,temp1.src_sys_inst_id from temp1
                            inner join temp2 on 
                            temp1.customer_id = temp2.customer_id and 
                            temp1.src_sys_id = temp2.src_sys_id and 
                            temp1.src_sys_inst_id = temp2.src_sys_inst_id
                            """)

    return temp


def getPersonCustomerRefDataDriver(spark, refdataframe, mongo_collection_read):
    cust_id = [int(i.customer_id) for i in refdataframe.select('customer_id').collect()]

    pipeline = "[{ $project: {_id: 1, customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_extract_ts:1}},{'$match': {'customer_id':{$in: " + str(
        cust_id) + "}}}]"

    reference_data_df = read_from_mongo(spark, mongo_collection_read, pipeline)
    return reference_data_df


def getNonExist_Records_in_PersonCustomer(spark, checktable, percusttable, drive_mongo_collection):
    if (checktable.count()) > 0:
        temp_dff = checktable.filter(~checktable["customer_id"].isin(
            [int(i.customer_id) for i in percusttable.select("customer_id").collect()]))
        cust_exit_df = percusttable.join(temp_dff, "customer_id", "left_anti")
        print('------------------cust_exit_df------------------')
        cust_exit_df.show(1000)

        print('------------------temp_dff------------------')
        temp_dff.show(1000)

        if temp_dff.count() > 0:
            temp_dff = temp_dff.dropDuplicates()
            personal_customer_df_temp = getPersonCustomerRefDataDriver(spark, temp_dff, drive_mongo_collection)

            if personal_customer_df_temp.count() == 0:
                personal_customer_df_temp = getPersonCustomerRefData(spark, temp_dff, mongo_write_collection)

            if personal_customer_df_temp.count() > 0:
                personal_customer_df_temp = personal_customer_df_temp.drop('_id')
                personal_customer_df_temp = getdiff_records(spark, personal_customer_df_temp, temp_dff)
                if cust_exit_df.count() > 0:
                    cust_exit_df.createorreplacetempview("custexit_df")
                    personal_customer_df_temp.createorreplacetempview("personal_customer_df_temp")
                    percusttable = spark.sql(""" SELECT customer_id,src_extract_ts,src_sys_id,src_sys_inst_id from custexit_df
                    UNION
                    SELECT customer_id,src_extract_ts,src_sys_id,src_sys_inst_id from personal_customer_df_temp                    
                    """)
                    percusttable = percusttable.withColumn("src_evt_typ_flg", lit("in"))
                else:
                    percusttable = personal_customer_df_temp.withColumn("src_evt_typ_flg", lit("in"))

            else:
                percusttable = cust_exit_df
        else:
            percusttable = cust_exit_df

    percusttable = getCombinedExistNonExitCustomer(spark, percusttable, mongo_write_collection)
    print('------------percusttable-------------')
    percusttable.show()
    return percusttable


def getPersonCustomerRefData(spark, refdataframe, mongo_collection_write):
    pipeline = "[{ $project: {_id: 1, customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1,src_extract_ts:1}},{'$match': {'customer_id':{$in: " + str(
        [int(i.customer_id) for i in refdataframe.select('customer_id').collect()]) + "}}}]"
    reference_data_df = read_from_mongo(spark, mongo_collection_write, pipeline)
    return reference_data_df

def getEmptyDataFrame(refDataFrame, filtertable):
    tempDF = refDataFrame.filter(
        refDataFrame['SRC_INGEST_MAP'] == filtertable)
    return tempDF

def handle_status_flag(spark, df):
    try:
        not_up_status_df = df.filter(((df['src_evt_typ_flg'] != "up") & (df['src_evt_typ_flg'] != "dl")))
        if not_up_status_df.count() > 0:
            in_yes_df = not_up_status_df.filter(((df['record_status'] == "yes")))
            if in_yes_df.count() > 0:
                in_yes_df = in_yes_df.drop('record_status')
                in_yes_df.createOrReplaceTempView("in_yes_df")
                pipeline = "[{ $project: {_id: 1, customer_id: 1,customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1}},{'$match': {'customer_id':{$in: " + str(
                    [int(i.customer_id) for i in in_yes_df.select('customer_id').collect()]) + "}}}]"
                # print(pipeline)
                reference_yes_df = read_from_mongo(spark, mongo_write_collection, pipeline)
                if reference_yes_df.count() > 0:
                    reference_yes_df.createOrReplaceTempView("reference_yes_df")
                    status_yes_df = spark.sql("""  select distinct b._id,a.* from in_yes_df a
                                               inner join reference_yes_df b on a.customer_id=b.customer_id
                                               and a.src_sys_id=b.src_sys_id and a.src_sys_inst_id=b.src_sys_inst_id
                                               """)

                    write_to_mongo(status_yes_df, mongo_write_collection)
            in_no_df = not_up_status_df.filter(((df['record_status'] == "no")))
            if in_no_df.count() > 0:
                in_no_df = in_no_df.drop('record_status')
                write_to_mongo(in_no_df, mongo_write_collection)

        up_status_df = df.filter(((df['src_evt_typ_flg'] == "up") | (df['src_evt_typ_flg'] == "dl")))
        up_status_df = up_status_df.drop('record_status')
        up_status_df.createOrReplaceTempView("up_status_data")
        if (up_status_df.count()) > 0:
            print(str(datetime.now().strftime(
                 '%Y-%m-%d %H:%M:%S')) + ":: processing started for records. writing logical source datasss in "
                                        "mongodb for src_evt_typ_flg up or dl status "
                                        "collection: " + mongo_write_collection)

            pipeline = "[{ $project: {_id: 1, customer_id: 1,customer_id: 1,src_sys_id:1,src_sys_inst_id:1,src_evt_typ_flg:1}},{'$match': {'customer_id':{$in: " + str(
                [int(i.customer_id) for i in up_status_df.select('customer_id').collect()]) + "}}}]"
            reference_data_df = read_from_mongo(spark, mongo_write_collection, pipeline)
            if reference_data_df.count() > 0:
                reference_data_df.createOrReplaceTempView("reference_data")
                up_status_data_df = spark.sql("""  select distinct b._id,a.* from up_status_data a
                                                                   inner join reference_data b on a.customer_id=b.customer_id
                                                                   and a.src_sys_id=b.src_sys_id  and a.src_sys_inst_id=b.src_sys_inst_id
                                                                   """)

                write_to_mongo(up_status_data_df, mongo_write_collection)
            else:
                up_status_df.show(1000)
                write_to_mongo(up_status_df, mongo_write_collection)
            print(str(datetime.now().strftime(
                 '%Y-%m-%d %H:%M:%S')) + ":: processing done for records. writing  logical source data in "
                                        "mongodb "
                                        "for src_evt_typ_flg up or dl status "
                                        "collection: " + mongo_write_collection)

    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def read_from_mongo(spark, collection, pipeline):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime(
            '%Y-%m-%d %H:%M:%S')) + ":: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', False) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ":: Written CDB  Logical Source "
                                                                  "Data in MongoDB collection: " + mongo_write_collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())

def getMongoDBConfiguration():
    try:
        config = configparser.ConfigParser()
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        raise ex


def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ods_ls_cdb_ind_indicators_eod","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex


if __name__ == '__main__':
    main()
