__author__ = "dvbbf"
# Filename: ls_driver_cust_rel.py
# Mapping:
# TRN_NME:
#
# Source/Target details:
# Input : STREAMING.CDB.CUST-CUST-REL.STD
# Output: Mongo Collection- LS_DRIVER_CUST_REL
#

#######################################################################################################################
from pyspark.sql.utils import ParseException, QueryExecutionException, AnalysisException
from py4j.protocol import Py4JJavaError
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_json, struct, lit, col
from datetime import datetime
import sys
import os
if sys.version_info[0] == 2:
    import ConfigParser as configparser
else:
    import configparser



class MongoException(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message

class KafkaError(BaseException):
    def __init__(self, message):
        super().__init__()
        self.message = message

    def getmessage(self):
        return self.message



## Variables populated at runtime
path_kafka_hdfs = sys.argv[1]
mongo_driver_collection = sys.argv[2]
kafka_source_topic_customer_rel = sys.argv[3]

#######################################################################################################################

def main():
    try:


        # 0 - disables show, 1 - enables show
        debug = 1;
        spark = SparkSession.builder.config("spark.sql.warehouse.dir", "/etc/hive/conf/hive-site.xml").getOrCreate()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ' :: SPARK SESSION INITIALIZED. STARTING LS_CDB_DRIVER_CUST_REL PIPELINE!!!! ')
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'INITIATED', 'Started identifying new Customer_Relationship records')

        ## Reading records from KAFKA_HDFS_PATH
        # print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" :: Path: "+path_kafka_hdfs)
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ' :: Fetching records from Kafka_HDFS ')
        record_from_kafka_hdfs = spark.read.json(path_kafka_hdfs);

        # Reading Customer_Relationship records -- excluded: SRC_EVT_TYP_FLG
        cust_rel_df = record_from_kafka_hdfs.select("CUSTOMER_ID_1", "CUSTOMER_ID_2", "SRC_SYS_ID", "SRC_SYS_INST_ID",
            "REL_TYPE", "SRC_EXTRACT_TS").filter(record_from_kafka_hdfs['SRC_INGEST_MAP'] == kafka_source_topic_customer_rel)
        try: pCust_cnt = cust_rel_df.count()
        except: pCust_cnt=0

        if pCust_cnt <= 0:
            ## If there are no records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: No records to read, aborting the process successfully")
            writeApplicationStatusToFile(spark,path_kafka_hdfs, '0_RECORDS', 'No records to identify new records.')
            exit(0)
        else:
            ## If there are records available
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Found '" + str(pCust_cnt) + "' customer records")
            if debug == 1: cust_rel_df.show(5, truncate=False)



        #Get distinct records from Source
        for col in cust_rel_df.columns:
            cust_rel_df = cust_rel_df.withColumnRenamed(col, col.lower())

        cust_rel_df.createOrReplaceTempView("customer_relationship")
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Removing duplicate customer records, if any.")
        custRelId_df = spark.sql("""SELECT DISTINCT customer_id_1, customer_id_2, src_sys_id, src_sys_inst_id, rel_type, 
            src_extract_ts from customer_relationship where customer_id_1 IS NOT NULL""")
        if debug == 1: custRelId_df.show(5, truncate=False)

        ## Get matching records from Driver_data
        pp_cols_df = custRelId_df.select("customer_id_1", "customer_id_2", "src_sys_id", "src_sys_inst_id", "rel_type")

        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Generating pipeline for unmatched records")
        pipeline = "[{ $project: {_id: 1, customer_id_1:1, customer_id_2:1, src_sys_id:1, src_sys_inst_id:1, rel_type:1}}," \
            "{'$match': " \
                "{'customer_id_1':{$in: " + str([int(i.customer_id_1) for i in custRelId_df.select('customer_id_1').collect()]) + "}}" \
            "}]"

        if debug==1: print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Pipeline\n"+pipeline)
        # drv_pCustId_df = read_from_mongo(spark, mongo_driver_collection)
        drv_pCustRelId_df = read_from_mongo_pipeline(spark, mongo_driver_collection, pipeline)
        try: drv_pcust_cnt = drv_pCustRelId_df.count()
        except: drv_pcust_cnt=0

        # ################################ INCREMENTAL LOAD #################################
        if drv_pcust_cnt > 0:
            print(str(datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')) + " :: Received records from "+mongo_driver_collection+" collection through Pipeline")
            if debug==1: drv_pCustRelId_df.show(5, truncate=False)

            custRelId_df.createOrReplaceTempView("new_customer_tbl")
            drv_pCustRelId_df.createOrReplaceTempView("drv_customer_tbl")

            # Extract new customer set of records
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Identifying new records, if any.")
            new_CustIDs_df = custRelId_df.join(drv_pCustRelId_df, on=['customer_id_1', 'customer_id_2', 'src_sys_id',
                                                                    'src_sys_inst_id', 'rel_type'], how='left_anti')
            try: new_rec_cnt = new_CustIDs_df.count()
            except: new_rec_cnt=0

            ## Checking if there are any new records
            if new_rec_cnt > 0:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are "+str(new_rec_cnt)+" new record(s) identified")
                writeApplicationStatusToFile(spark,path_kafka_hdfs, 'RECORDS_AVAILABLE','Identified new Personal_Customer records');
                if debug == 1: new_CustIDs_df.show(5, truncate=False)

                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing New record(s) to MongoDB- "+mongo_driver_collection)
                write_to_mongo(new_CustIDs_df, mongo_driver_collection)
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Successfully written to MongoDB")
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed the process")
            else:
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: There are 0 new records identified")
                writeApplicationStatusToFile(spark,path_kafka_hdfs, 'NO_RECORDS', 'Found 0 new records')
                print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed the process.")
        else:
            ## Init load
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: All received Customer_ID's are new records.")

            ## Write new records to driver collection
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Writing data to collection -"+mongo_driver_collection)
            write_to_mongo(custRelId_df, mongo_driver_collection)
            writeApplicationStatusToFile(spark,path_kafka_hdfs, 'RECORDS_AVAILABLE', 'Identified new Personal_Customer records')
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Data written to collection successfully.")
            print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Completed successfully.")

    except ParseException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryParserError', str(ex))
    except QueryExecutionException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'SqlQueryExecutionError', str(ex))
    except AnalysisException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'DataFrameError', str(ex))
    except KafkaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'KafkaError', str(ex.getmessage()))
    except MongoException as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'MongoError', str(ex.getmessage()))
    except Py4JJavaError as ex:
        writeApplicationStatusToFile(spark,path_kafka_hdfs, 'GeneralError',
                                     ex.java_exception.toString())


# ##################################################### UTILITIES ##############################################################################################

def read_from_mongo(spark, collection):
    try:
        db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .load()
        print(collection + " from MongoDB loaded to SPARK!")
        return df
    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def getMongoDBConfiguration():
    try:

        config = configparser.ConfigParser()
        # config.read(configFilePath)
        config.read(os.getcwd() + '/dbConfiguration.ini')
        db_url = config.get('mongodb-configuration', 'db_url')
        db_database = config.get('mongodb-configuration', 'db_database')
        return db_url, db_database
    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def read_from_mongo_pipeline(spark, collection, pipeline):
    try:
        db_url, db_database = getMongoDBConfiguration()
        # db_url, db_database = getMongoDBConfiguration()
        df = spark.read.format("com.mongodb.spark.sql.DefaultSource") \
            .option('uri', db_url) \
            .option('database', db_database) \
            .option("collection", collection) \
            .option("pipeline", pipeline) \
            .load()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + ":: Loaded Source Collection: " + collection + " from MongoDB ")
        return df

    except Py4JJavaError as ex:
        print("An error occurred: " + ex.java_exception.toString())

def write_to_mongo(df, collection):
    try:
        db_url, db_database = getMongoDBConfiguration()
        # db_url, db_database = getMongoDBConfiguration()
        df.write.format("com.mongodb.spark.sql.DefaultSource") \
            .mode("append") \
            .option('uri', db_url) \
            .option("database", db_database) \
            .option("collection", collection) \
            .option('replaceDocument', False) \
            .save()
        print(str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + " :: Written Data into MongoDB collection: " + collection)
    except Py4JJavaError as ex:
        raise MongoException(ex.java_exception.toString())


def writeApplicationStatusToFile(spark,data_file, status, message):
    try:

        cSchema = StructType([StructField("filename", StringType()) \
                                 , StructField("status", StringType()) \
                                 , StructField("date", DateType())
                                 , StructField("ls_layer", StringType()) \
                                 , StructField("message", StringType())                              \
                              ])

        dateTimeObj = datetime.now()
        objlist=[]
        objlist.append({"filename":data_file,"status":status,"date":dateTimeObj,"ls_layer":"ls_cdb_driver_cust_relationship","message":message})
        df = spark.createDataFrame(objlist, schema=cSchema)
        write_to_mongo(df,"ods_ldb_cdb_audit_details")
    except Py4JJavaError as ex:
        raise ex


if __name__ == '__main__':
    main()
